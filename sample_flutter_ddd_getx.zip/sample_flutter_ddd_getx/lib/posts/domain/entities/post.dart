// class Post {
//   final Title title;
//   final BodyText bodyText;
//
//   Post({required this.title, required this.bodyText});
// }
//
class Post {
  final String title;
  final String bodyText;

  Post({required this.title, required this.bodyText});
}
