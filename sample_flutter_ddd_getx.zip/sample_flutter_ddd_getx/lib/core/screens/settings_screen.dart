import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sample_flutter_ddd_getx/core/controllers/theme_controller.dart';
import 'package:sample_flutter_ddd_getx/core/models/menu_option_model.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Settings"),
      ),
      body: ListView(
        children: [
          themePopUpMenuButton(),
        ],
      ),
    );
  }

  themePopUpMenuButton() {
    final List<MenuOptionsModel> themeOptions = [
      MenuOptionsModel(
          key: "system", value: 'System', icon: Icons.brightness_4),
      MenuOptionsModel(
          key: "light", value: 'Light', icon: Icons.brightness_low),
      MenuOptionsModel(key: "dark", value: 'Dark', icon: Icons.brightness_3)
    ];
    return GetBuilder<ThemeController>(
      builder: (controller) => ListTile(
        title: Text("Change Theme"),
        trailing: PopupMenuButton<MenuOptionsModel>(
          icon: Icon(Icons.more_vert),
          onSelected: (choice) {
            controller.setThemeMode(choice.key);
          },
          itemBuilder: (BuildContext context) {
            return themeOptions.map((MenuOptionsModel choice) {
              return PopupMenuItem<MenuOptionsModel>(
                value: choice,
                child: Text("${choice.value}"),
              );
            }).toList();
          },
        ),
      ),
    );
  }
}
