import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:package_info/package_info.dart';
import 'package:sample_flutter_ddd_getx/common/utils/utils.dart';

import '../../auth/presentation/controller/auth_controller.dart';
import '../models/menu_option_model.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("App DashBoard"),
        actions: [
          signOutButton(),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: buildDashboardMenu()),
          buildUserInfo(),
          buildAppVersion(),
          SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget buildDashboardMenu() {
    final List<MenuOptionsModel> dashboardLinks = [
      MenuOptionsModel(
        key: "1",
        value: 'Posts',
        icon: Icons.book,
        path: "/posts",
      ),
      MenuOptionsModel(
          key: "3",
          value: 'Manage Expenses',
          icon: Icons.receipt,
          path: "/expenses"),
      MenuOptionsModel(
        key: "2",
        value: 'Settings',
        icon: Icons.settings,
        path: "/settings",
      ),
    ];
    return GridView.builder(
      shrinkWrap: true,
      padding: EdgeInsets.all(20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 10,
        mainAxisSpacing: 20,
      ),
      itemCount: dashboardLinks.length,
      itemBuilder: (BuildContext context, int index) {
        return Container(
          color: Colors.blueGrey,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () {
                Get.toNamed(dashboardLinks[index].path!);
              },
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      dashboardLinks[index].icon,
                      size: 30,
                      color: Colors.white,
                    ),
                    SizedBox(height: 5),
                    Text(
                      dashboardLinks[index].value,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyText1,
                    )
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget signOutButton() {
    return GetBuilder<AuthController>(
      init: AuthController(),
      builder: (controller) => IconButton(
        onPressed: () {
          controller.signOut();
        },
        icon: Icon(Icons.logout),
      ),
    );
  }

  Widget buildUserInfo() {
    return GetBuilder<AuthController>(
      init: AuthController(),
      builder: (controller) => Text("${controller.user.value!.name}"),
    );
  }

  Widget buildAppVersion() {
    return FutureBuilder<PackageInfo>(
      future: Utils.getPackageInfo(),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        if (snapshot.hasData) {
          final packageInfo = snapshot.data;
          return Text("${packageInfo.version}");
        }
        return Text("wait");
      },
    );
  }
}
