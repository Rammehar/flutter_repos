import 'package:flutter/material.dart';

class ExpensesManagementDashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Expenses Dashboard"),
      ),
      body: Center(
        child: Text("Expenses Management"),
      ),
    );
  }
}
