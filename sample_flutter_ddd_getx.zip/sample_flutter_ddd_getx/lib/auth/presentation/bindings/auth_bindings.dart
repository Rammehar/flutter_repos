import 'package:get/get.dart';
import 'package:sample_flutter_ddd_getx/auth/application/auth_facade_service.dart';
import 'package:sample_flutter_ddd_getx/auth/presentation/controller/auth_controller.dart';

class AuthBindings extends Bindings {
  @override
  void dependencies() {
    Get.put(AuthFacadeService(), permanent: true);
    Get.put(AuthController(), permanent: true);
  }
}
