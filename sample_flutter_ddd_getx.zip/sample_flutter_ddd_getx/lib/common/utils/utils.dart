import 'package:package_info/package_info.dart';

class Utils {
  static Future<PackageInfo> getPackageInfo() async {
    final PackageInfo packageInfo = await PackageInfo.fromPlatform();
    return packageInfo;
  }
}
