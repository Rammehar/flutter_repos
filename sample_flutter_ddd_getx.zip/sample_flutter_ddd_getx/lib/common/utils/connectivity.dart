class Connectivity {
  get isConnected {
    return true;
  }
}
