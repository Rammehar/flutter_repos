const devBaseUrl = "https://jsonplaceholder.typicode.com";
const prodBaseUrl = "https://jsonplaceholder.typicode.com";
