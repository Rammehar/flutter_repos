import 'dart:async';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'common/config/constants.dart';
import 'common/config/flavor_config.dart';
import 'core/controllers/theme_controller.dart';
import 'core/screens/my_app.dart';

void main() async {
  runZonedGuarded(
    () async {
      WidgetsFlutterBinding.ensureInitialized();
      await SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);

      //get Error if any
      FlutterError.onError = (FlutterErrorDetails details) {
        log(details.exceptionAsString(), stackTrace: details.stack);
      };
      await Hive.initFlutter();
      await GetStorage.init();
      Get.put<ThemeController>(ThemeController());

      FlavorConfig(
          flavor: Flavor.prod,
          color: Colors.green,
          values: FlavorValues(baseUrl: prodBaseUrl));
      runApp(MyApp());
    },
    (Object error, StackTrace stackTrace) {
      log(error.toString(), stackTrace: stackTrace);
    },
  );
}
