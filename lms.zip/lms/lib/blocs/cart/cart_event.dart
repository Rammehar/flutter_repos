import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';

import '../../models/order_model.dart';
import '../../models/user_model.dart';

abstract class CartEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class LoadCart extends CartEvent {
  final User user;
  LoadCart({@required this.user}) : assert(user != null);
  @override
  List<Object> get props => [user];
}

class AddToCart extends CartEvent {
  final String courseid;
  final User user;
  AddToCart(this.courseid, this.user);
  @override
  List<Object> get props => [courseid, user];
  @override
  String toString() => 'AddedToCart { AddedToCart: $courseid and $user }';
}

class RemoveFromCart extends CartEvent {
  final String courseid;
  final User user;
  RemoveFromCart(this.courseid, this.user);
  @override
  List<Object> get props => [courseid, user];
  @override
  String toString() => 'RemoveFromCart { RemoveFromCart: $courseid and $user }';
}

class EmptyCart extends CartEvent {
  final User user;
  EmptyCart({@required this.user}) : assert(user != null);
  @override
  List<Object> get props => [user];
}

class CheckoutButtonPressed extends CartEvent {
  final Order order;
  CheckoutButtonPressed({this.order});
  @override
  List<Object> get props => [order];
  @override
  String toString() => 'CheckoutButtonPressed { CheckoutButtonPressed: $order}';
}
