import 'package:equatable/equatable.dart';

import '../../models/cart_model.dart';
import '../../models/order_model.dart';
import '../../models/user_model.dart';

abstract class CartState extends Equatable {
  const CartState();
}

class CartLoadingInProgress extends CartState {
  @override
  List<Object> get props => [];
}

class CartLoadedSuccess extends CartState {
  final Cart cart;
  final User user;
  CartLoadedSuccess([this.cart, this.user]);
  int get countItems => cart.totalCourses;
  @override
  List<Object> get props => [cart, user];
  String toString() => 'CartLoadedSuccess { CartLoadedSuccess: $cart }';
}

class OrderLoadedSuccess extends CartState {
  final Order order;
  OrderLoadedSuccess([this.order]);
  @override
  List<Object> get props => [order];
  @override
  String toString() =>
      'OrderLoadedSuccess { OrderLoadedSuccess: ${order.userId} }';
}

class CartError extends CartState {
  final Exception errorMessage;
  CartError({this.errorMessage});

  @override
  List<Object> get props => [errorMessage];

  @override
  String toString() => 'CartError { ErrorMsg: $errorMessage }';
}
