import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';

import './cart.dart';
import '../../repositories/cart_repository.dart';
import '../../repositories/order_repository.dart';

class CartBloc extends Bloc<CartEvent, CartState> {
  final CartRepository cartRepository;
  final OrderRepository orderRepository;
  CartBloc({
    @required this.cartRepository,
    @required this.orderRepository,
  })  : assert(cartRepository != null),
        super(CartLoadingInProgress());

  @override
  Stream<CartState> mapEventToState(CartEvent event) async* {
    if (event is LoadCart) {
      yield* _mapCartLoadToState(event.user);
    }
    if (event is AddToCart) {
      yield* _mapAddCourseToState(event);
    }
    if (event is RemoveFromCart) {
      yield* _mapRemoveCourseToState(event);
    }
    if (event is EmptyCart) {
      try {
        final cartItems = await cartRepository.fetchCartItems(event.user);
        yield CartLoadedSuccess(cartItems, event.user);
      } catch (err) {
        yield CartError(errorMessage: err);
      }
    }
    if (event is CheckoutButtonPressed) {
      yield* _mapCheckOutLoadToState(event);
    }
  }

  Stream<CartState> _mapCheckOutLoadToState(
      CheckoutButtonPressed event) async* {
    yield CartLoadingInProgress();
    try {
      var orderData = await orderRepository.addOrder(event.order);
      yield OrderLoadedSuccess(orderData);
    } catch (err) {
      yield CartError(errorMessage: err);
    }
  }

  Stream<CartState> _mapCartLoadToState(user) async* {
    yield CartLoadingInProgress();
    try {
      final cartItems = await cartRepository.fetchCartItems(user);
      yield CartLoadedSuccess(cartItems, user);
    } catch (err) {
      yield CartError(errorMessage: err);
    }
  }

  Stream<CartState> _mapAddCourseToState(AddToCart event) async* {
    final currentState = state;
    yield CartLoadingInProgress();
    if (currentState is CartLoadedSuccess) {
      try {
        final cartItems = await cartRepository.addCourseToCart(
            event.courseid, event.user.userId);
        yield CartLoadedSuccess(cartItems, event.user);
      } catch (err) {
        yield CartError(errorMessage: err);
      }
    }
  }

  Stream<CartState> _mapRemoveCourseToState(RemoveFromCart event) async* {
    final currentState = state;
    yield CartLoadingInProgress();
    if (currentState is CartLoadedSuccess) {
      try {
        final cartItems = await cartRepository.removeCourseFromCart(
            event.courseid, event.user.userId);
        yield CartLoadedSuccess(cartItems, event.user);
      } catch (err) {
        yield CartError(errorMessage: err);
      }
    }
  }
}
