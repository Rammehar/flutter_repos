import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';

import '../../blocs/cart/cart.dart';
import 'cart_icon.dart';

class CartIconBloc extends Bloc<CartIconEvent, CartIconState> {
  final CartBloc cartBloc;
  StreamSubscription _cartSubscription;
  CartIconBloc({@required this.cartBloc})
      : super(
          cartBloc.state is CartLoadedSuccess
              ? LoadedTotalItemsInCart(
                  (cartBloc.state as CartLoadedSuccess).countItems,
                )
              : Initial(),
        ) {
    _cartSubscription = cartBloc.listen((state) {
      if (state is CartLoadedSuccess) {
        add(UpdateCartIconData(
            (cartBloc.state as CartLoadedSuccess).countItems));
      }
    });
  }

  @override
  Future<void> close() {
    _cartSubscription?.cancel();
    return super.close();
  }

  @override
  Stream<CartIconState> mapEventToState(CartIconEvent event) async* {
    if (event is UpdateCartIconData) {
      yield LoadedTotalItemsInCart(event.totalCourseInCart);
    }
  }
}
