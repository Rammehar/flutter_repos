import 'package:equatable/equatable.dart';

abstract class CartIconEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class LoadCartIcon extends CartIconEvent {
  @override
  List<Object> get props => [];
}

class UpdateCartIconData extends CartIconEvent {
  final int totalCourseInCart;
  UpdateCartIconData([this.totalCourseInCart]);
  @override
  List<Object> get props => [totalCourseInCart];
}
