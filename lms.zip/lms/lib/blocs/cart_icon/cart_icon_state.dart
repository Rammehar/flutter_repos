import 'package:equatable/equatable.dart';

abstract class CartIconState extends Equatable {
  const CartIconState();
}

class Initial extends CartIconState {
  @override
  List<Object> get props => [];
}

class LoadedTotalItemsInCart extends CartIconState {
  final int totalCourseInCart;
  LoadedTotalItemsInCart(this.totalCourseInCart);
  @override
  List<Object> get props => [totalCourseInCart];
  String toString() =>
      'LoadedTotalItemsInCart { LoadedTotalItemsInCart: $totalCourseInCart }';
}
