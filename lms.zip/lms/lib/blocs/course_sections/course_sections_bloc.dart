import 'package:bloc/bloc.dart';
import '../../models/course_model.dart';
import '../../repositories/section_repository.dart';
import 'course_sections_event.dart';
import 'course_sections_state.dart';

class CourseSectionsBloc
    extends Bloc<CourseSectionsEvent, CourseSectionsState> {
  final SectionsRepository sectionsRepository;

  CourseSectionsBloc({this.sectionsRepository})
      : assert(sectionsRepository != null),
        super(CourseSectionsLoadInProgress());

  @override
  Stream<CourseSectionsState> mapEventToState(
      CourseSectionsEvent event) async* {
    if (event is GetCourseSections) {
      yield* _mapCourseSectionsLoadedToState(event);
    }
  }

  Stream<CourseSectionsState> _mapCourseSectionsLoadedToState(
      GetCourseSections event) async* {
    print('event is ${event.data}');
    try {
      final courseDetails = await sectionsRepository
          .fetchCourseWithSectionsByCourseId(event.data);
      yield CourseSectionsLoadSuccess(courseDetails);
    } catch (err) {
      yield CourseSectionsLoadFailure(errorMessage: err);
    }
  }
}
