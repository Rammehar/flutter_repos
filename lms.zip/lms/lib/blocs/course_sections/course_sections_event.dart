import 'package:equatable/equatable.dart';

class CourseSectionsEvent extends Equatable {
  const CourseSectionsEvent();

  @override
  List<Object> get props => [];
}

class GetCourseSections extends CourseSectionsEvent {
  final data;
  GetCourseSections([this.data]);
  @override
  List<Object> get props => [data];
}
