import '../../models/course_model.dart';
import 'package:equatable/equatable.dart';

abstract class CourseSectionsState extends Equatable {
  const CourseSectionsState();

  @override
  List<Object> get props => [];
}

class CourseSectionsInitialState extends CourseSectionsState {}

class CourseSectionsLoadInProgress extends CourseSectionsState {}

class CourseSectionsLoadSuccess extends CourseSectionsState {
  final Course courseDetails;
  CourseSectionsLoadSuccess([this.courseDetails]);
  @override
  List<Object> get props => [courseDetails];

  @override
  String toString() =>
      'CourseSectionsLoadSuccess { CourseSectionsLoadSuccess: $courseDetails }';
}

class CourseSectionsLoadFailure extends CourseSectionsState {
  final Exception errorMessage;
  CourseSectionsLoadFailure({this.errorMessage});
  @override
  List<Object> get props => [errorMessage];

  @override
  String toString() => 'CourseSectionsLoadFailure { settings: $errorMessage }';
}
