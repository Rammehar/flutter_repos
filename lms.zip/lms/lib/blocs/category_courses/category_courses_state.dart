import '../../models/category_model.dart';
import 'package:equatable/equatable.dart';

abstract class CategoryCoursesState extends Equatable{
  CategoryCoursesState();

  @override
  List<Object> get props => [];
}

class CategoryCoursesLoadInProgress extends CategoryCoursesState{}

class CategoryCoursesLoadSuccess extends CategoryCoursesState{
  final Category categoryWithCourses;
  CategoryCoursesLoadSuccess([this.categoryWithCourses]);

  @override
  List<Object> get props=>[categoryWithCourses];

  @override
  String toString() =>"CategoryCoursesLoadSuccess $categoryWithCourses";

}

class CategoryCoursesLoadFailure extends CategoryCoursesState{
  final Exception errorMessage;
  CategoryCoursesLoadFailure({this.errorMessage});

  @override
  List<Object> get props=>[errorMessage];

  @override
  String toString()=> "CategoryCoursesLoadFailure{ message : $errorMessage}";
}