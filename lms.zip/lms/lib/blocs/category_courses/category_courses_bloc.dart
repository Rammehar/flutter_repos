import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';

import '../../repositories/category_repository.dart';
import 'category_courses.dart';

class CategoryCoursesBloc
    extends Bloc<CategoryCoursesEvent, CategoryCoursesState> {
  CategoryRepository categoryRepository;

  CategoryCoursesBloc({@required this.categoryRepository})
      : assert(categoryRepository != null),
        super(CategoryCoursesLoadInProgress());

  @override
  Stream<CategoryCoursesState> mapEventToState(
      CategoryCoursesEvent event) async* {
    if (event is CategoryCoursesFetched) {
      try {
        yield CategoryCoursesLoadInProgress();
        final categoryCourses = await categoryRepository
            .fetchCoursesByCategoryId(event.categoryId, event.user);
        yield CategoryCoursesLoadSuccess(categoryCourses);
      } catch (err) {
        yield CategoryCoursesLoadFailure(errorMessage: err);
      }
    }
  }
}
