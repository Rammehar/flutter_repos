import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';

import '../../models/user_model.dart';

class CategoryCoursesEvent extends Equatable {
  CategoryCoursesEvent();
  @override
  List<Object> get props => [];
}

class CategoryCoursesFetched extends CategoryCoursesEvent {
  final String categoryId;
  final User user;
  CategoryCoursesFetched({@required this.categoryId, this.user})
      : assert(categoryId != null);
//  @override
//  List<Object> get props => [categoryId, user];
  @override
  String toString() => 'CategoryCoursesFetched { categoryId: $categoryId }';
}
