import 'package:equatable/equatable.dart';

class FeedBackState extends Equatable {
  const FeedBackState();
  @override
  List<Object> get props => [];
}

class FeedBackInitialState extends FeedBackState {}

class FeedBackLoadingState extends FeedBackState {}

class FeedBackLoadedState extends FeedBackState {
  final bool feedback;
  final String message;
  FeedBackLoadedState({this.feedback, this.message});
  @override
  List<Object> get props => [feedback, message];
  @override
  String toString() => 'FeedBackLoadedState { feedback: $feedback }';
}

class FeedBackErrorState extends FeedBackState {
  final Exception errorMessage;
  FeedBackErrorState({this.errorMessage});
  @override
  List<Object> get props => [errorMessage];
  @override
  String toString() => 'FeedBackErrorState { errorMessage: $errorMessage }';
}
