import 'package:bloc/bloc.dart';
import '../../repositories/feedback_repository.dart';
import '../../blocs/feedback/feedback.dart';

class FeedBackBloc extends Bloc<FeedBackEvent, FeedBackState> {
  final FeedBackRepository feedBackRepository;

  FeedBackBloc({this.feedBackRepository})
      : assert(feedBackRepository != null),
        super(FeedBackInitialState());

  @override
  Stream<FeedBackState> mapEventToState(FeedBackEvent event) async* {
    if (event is FeedBackLoadedEvent) {
      yield FeedBackLoadedState(feedback: event.feedBack);
    }
    if (event is FeedBackAddEvent) {
      yield FeedBackLoadingState();
      try {
        var feedBack = await feedBackRepository.addFeedBack(event.feedBack);
        yield FeedBackLoadedState(
            feedback: feedBack['feedback'], message: feedBack['message']);
      } catch (err) {
        yield FeedBackErrorState(errorMessage: err);
      }
    }
  }
}
