import '../../models/feedback_model.dart';
import 'package:equatable/equatable.dart';

class FeedBackEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class FeedBackAddEvent extends FeedBackEvent {
  final FeedBack feedBack;
  FeedBackAddEvent({this.feedBack});
  @override
  List<Object> get props => [feedBack];
}

class FeedBackLoadedEvent extends FeedBackEvent {
  final bool feedBack;
  FeedBackLoadedEvent({this.feedBack});
  @override
  List<Object> get props => [feedBack];
}
