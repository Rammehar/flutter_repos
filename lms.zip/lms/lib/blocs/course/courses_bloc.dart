import 'package:flutter/material.dart';
import 'package:bloc/bloc.dart';
import 'package:rxdart/rxdart.dart';
import '../../repositories/courses_repository.dart';
import './courses_event.dart';
import './courses_state.dart';

class CoursesBloc extends Bloc<CoursesEvent, CoursesState> {
  CoursesRepository coursesRepository;

  CoursesBloc({@required this.coursesRepository})
      : assert(coursesRepository != null),
        super(CoursesLoadInProgress());

//  @override
//  Stream<Transition<CoursesEvent, CoursesState>> transformEvents(
//    Stream<CoursesEvent> events,
//    Stream<Transition<CoursesEvent, CoursesState>> Function(
//      CoursesEvent event,
//    )
//        transitionFn,
//  ) {
//    return events
//        .where((event) {
//          return (event is CoursesSearchEvent);
//        })
//        .debounceTime(Duration(milliseconds: 300))
//        .switchMap(transitionFn);
//  }

  @override
  Stream<CoursesState> mapEventToState(CoursesEvent event) async* {
    if (event is AllCoursesFetched) {
      yield* _mapCoursesLoadedToState(event);
    }
    //search course
    if (event is CoursesSearchEvent) {
      yield CoursesLoadInProgress();
      try {
        final coursesList =
            await coursesRepository.searchCourses(event.query, event.user);
        yield CoursesLoadSuccess(coursesList);
      } catch (err) {
        print(err.toString());
        yield CoursesLoadFailure(errorMessage: err);
      }
    }
  }

  Stream<CoursesState> _mapCoursesLoadedToState(
      AllCoursesFetched event) async* {
    print("welcome");
    yield CoursesLoadInProgress();
    try {
      final coursesList = await coursesRepository.fetchCourses(event.user);
      yield CoursesLoadSuccess(coursesList);
    } catch (err) {
      yield CoursesLoadFailure(errorMessage: err);
    }
  }
}
