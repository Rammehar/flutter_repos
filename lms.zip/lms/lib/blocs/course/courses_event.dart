import 'package:equatable/equatable.dart';

import '../../models/user_model.dart';

abstract class CoursesEvent extends Equatable {
  const CoursesEvent();

  @override
  List<Object> get props => [];
}

class AllCoursesFetched extends CoursesEvent {
  final User user;
  const AllCoursesFetched({this.user});
}

class CoursesSearchEvent extends CoursesEvent {
  final String query;
  final User user;
  const CoursesSearchEvent({this.query, this.user});

  @override
  String toString() => 'CoursesSearchEvent { query: $query }';
}
