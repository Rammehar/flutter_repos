import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';

import '../../models/course_model.dart';

abstract class CoursesState extends Equatable {
  const CoursesState();
  @override
  List<Object> get props => [];
}

class CoursesLoadInProgress extends CoursesState {}

class CoursesLoadSuccess extends CoursesState {
  final List<Course> courses;
  CoursesLoadSuccess([this.courses]);
  @override
  List<Object> get props => [courses];
  @override
  String toString() => 'CoursesLoadSuccess { CoursesLoadSuccess: $courses }';
}

class CoursesLoadFailure extends CoursesState {
  final Exception errorMessage;
  CoursesLoadFailure({@required this.errorMessage});
  @override
  List<Object> get props => [errorMessage];
  @override
  String toString() => 'CoursesLoadFailure { message: $errorMessage }';
}
