import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

import './authentication.dart';
import '../../models/user_model.dart';
import '../../repositories/user_repository.dart';

class AuthenticationBloc
    extends Bloc<AuthenticationEvent, AuthenticationState> {
  UserRepository userRepository;
  AuthenticationBloc({@required this.userRepository})
      : assert(userRepository != null),
        super(Unauthenticated());

  @override
  Stream<AuthenticationState> mapEventToState(
      AuthenticationEvent event) async* {
    if (event is AppStarted) {
      final bool hasToken = await userRepository.hasToken();
      if (hasToken) {
        User user = await userRepository.getUserData();
        yield Authenticated(user: user);
      } else {
        yield Unauthenticated();
      }
    }

    if (event is LoggedIn) {
      yield Loading();
      await userRepository.persistToken(event.user);
      yield Authenticated(user: event.user);
    }

    if (event is LoggedOut) {
      yield Loading();
      await userRepository.deleteToken(event.user);
      yield Unauthenticated();
    }
  }
}
