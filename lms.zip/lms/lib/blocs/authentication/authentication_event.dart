import '../../models/user_model.dart';
import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class AuthenticationEvent extends Equatable {
  const AuthenticationEvent();

  @override
  List<Object> get props => [];
}

class AppStarted extends AuthenticationEvent {}

class LoggedIn extends AuthenticationEvent {
  final User user;
  LoggedIn({@required this.user});
  @override
  List<Object> get props => [user];
}

class LoggedOut extends AuthenticationEvent {
  final User user;
  LoggedOut({this.user});
  @override
  List<Object> get props => [user];
}
