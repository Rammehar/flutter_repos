import 'package:equatable/equatable.dart';

class FavoriteState extends Equatable {
  @override
  List<Object> get props => [];
}

class FavoriteInitialState extends FavoriteState {}

class FavoriteLoadedState extends FavoriteState {
  final bool isFavorite;
  FavoriteLoadedState({this.isFavorite});
  @override
  List<Object> get props => [isFavorite];
}

class FavoriteFailureState extends FavoriteState {
  final Exception errorMessage;
  FavoriteFailureState({this.errorMessage});
  @override
  List<Object> get props => [errorMessage];

  @override
  String toString() =>
      'FavoriteFailureState { FavoriteFailureState: $errorMessage }';
}
