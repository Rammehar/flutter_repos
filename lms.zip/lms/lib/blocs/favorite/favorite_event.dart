import 'package:equatable/equatable.dart';

class FavoriteEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class LoadFavoriteEvent extends FavoriteEvent {
  final bool isFavorite;
  LoadFavoriteEvent(this.isFavorite);
  @override
  List<Object> get props => [isFavorite];
}

class FavoriteToggleEvent extends FavoriteEvent {
  final bool isFavorite;
  final String userId;
  final String courseId;
  FavoriteToggleEvent({this.courseId, this.userId, this.isFavorite});
  @override
  List<Object> get props => [isFavorite, userId, courseId];
}
