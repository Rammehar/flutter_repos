import 'package:bloc/bloc.dart';
import '../../repositories/favorite_repository.dart';
import '../../blocs/favorite/favorite_event.dart';
import '../../blocs/favorite/favorite_state.dart';

class FavoriteBloc extends Bloc<FavoriteEvent, FavoriteState> {
  final FavoriteRepository favoriteRepository;
  FavoriteBloc({this.favoriteRepository}) : super(FavoriteInitialState());

  @override
  Stream<FavoriteState> mapEventToState(FavoriteEvent event) async* {
    if (event is FavoriteToggleEvent) {
      try {
        print("isFavorite ${event.isFavorite}");
        yield FavoriteLoadedState(isFavorite: event.isFavorite);
        await favoriteRepository.updateIsFavoriteStatusOfCourse(event);
      } catch (err) {
        yield FavoriteFailureState(errorMessage: err);
      }
    }
  }
}
