import 'package:bloc/bloc.dart';

import './theme_event.dart';
import './theme_state.dart';
import '../../common/app_theme.dart';

class ThemeBloc extends Bloc<ThemeEvent, ThemeState> {
  ThemeBloc() : super(ThemeState(appThemeData[AppTheme.LightTheme]));

  @override
  Stream<ThemeState> mapEventToState(ThemeEvent event) async* {
    if (event is ThemeChanged) {
      yield ThemeState(appThemeData[event.theme]);
    }
  }
}
