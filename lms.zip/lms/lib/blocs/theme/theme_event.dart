import 'package:equatable/equatable.dart';

import '../../common/app_theme.dart';

class ThemeEvent extends Equatable {
  const ThemeEvent();

  @override
  List<Object> get props => [];
}

class ThemeChanged extends ThemeEvent {
  final AppTheme theme;
  ThemeChanged(this.theme);
  @override
  List<Object> get props => [theme];
}
