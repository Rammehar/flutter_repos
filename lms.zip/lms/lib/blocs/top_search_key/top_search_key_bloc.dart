import 'package:bloc/bloc.dart';
import 'top_search_key_event.dart';
import 'top_search_key_state.dart';
import '../../repositories/top_search_key_repository.dart';

class TopSearchKeyBloc extends Bloc<TopSearchKeyEvent, TopSearchKeyState> {
  TopSearchKeyRepository topSearchKeyRepository;
  TopSearchKeyBloc({this.topSearchKeyRepository})
      : super(TopSearchKeyInitialState());

  @override
  Stream<TopSearchKeyState> mapEventToState(TopSearchKeyEvent event) async* {
    if (event is TopSearchKeyFetched) {
      try {
        List<String> keys = await topSearchKeyRepository.fetchTopSearchKeys();
        yield TopSearchKeyFetchedState(searchKeys: keys);
      } catch (err) {
        yield TopSearchKeyErrorState(errorMessage: err);
      }
    }
  }
}
