import 'package:equatable/equatable.dart';

abstract class TopSearchKeyState extends Equatable {
  @override
  List<Object> get props => [];
}

class TopSearchKeyInitialState extends TopSearchKeyState {}

class TopSearchKeyFetchedState extends TopSearchKeyState {
  final List<String> searchKeys;
  TopSearchKeyFetchedState({this.searchKeys});
  @override
  List<Object> get props => [searchKeys];
}

class TopSearchKeyErrorState extends TopSearchKeyState {
  final Exception errorMessage;
  TopSearchKeyErrorState({this.errorMessage});
  @override
  List<Object> get props => [errorMessage];
}
