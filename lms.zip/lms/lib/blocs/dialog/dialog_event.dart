import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';

abstract class DialogEvent extends Equatable {}

class ShowDialog extends DialogEvent {
  final String message;
  ShowDialog({@required this.message}):assert(message !=null);
  @override
  List<Object> get props => [message];
}

class HideDialog extends DialogEvent {
  @override
  List<Object> get props => [];
}