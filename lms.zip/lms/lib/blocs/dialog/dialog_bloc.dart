import 'package:bloc/bloc.dart';
import './dialog.dart';

class DialogBloc extends Bloc<DialogEvent, DialogState> {
  DialogBloc() : super(InitialDialogState());

  @override
  Stream<DialogState> mapEventToState(DialogEvent event) async* {
    if (event is ShowDialog) {
      print("Show dialog event is fired");
      yield DialogVisible(message: event.message);
    } else {
      yield DialogHidden();
    }
  }
}
