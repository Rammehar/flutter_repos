import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';

abstract class DialogState extends Equatable {}

class InitialDialogState extends DialogState {
  @override
  List<Object> get props => [];
}

class DialogHidden extends DialogState {
  @override
  List<Object> get props => [];
}

class DialogVisible extends DialogState {
  final String message;
  DialogVisible({@required this.message}):assert(message !=null);
  @override
  List<Object> get props => [message];
}
