import 'dart:async';

import 'package:bloc/bloc.dart';

import '../../repositories/order_repository.dart';
import 'order.dart';

class OrderBloc extends Bloc<OrderEvent, OrderState> {
  final OrderRepository orderRepository;
  OrderBloc({this.orderRepository}) : super(LoadingInProgress());

  @override
  Stream<OrderState> mapEventToState(OrderEvent event) async* {
    if (event is SaveOrder) {
      yield LoadingInProgress();
      try {
        var orderData = await orderRepository.addOrder(event.order);
        yield OrderSavedSuccess(orderData);
      } catch (err) {
        yield OrderError(errorMessage: err);
      }
    }
  }
}
