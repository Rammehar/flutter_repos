import 'package:equatable/equatable.dart';

import '../../models/order_model.dart';

abstract class OrderState extends Equatable {
  const OrderState();
}

class LoadingInProgress extends OrderState {
  @override
  List<Object> get props => [];
}

class OrderSavedSuccess extends OrderState {
  final Order order;
  OrderSavedSuccess([this.order]);
  @override
  List<Object> get props => [order];
  @override
  String toString() =>
      'OrderLoadedSuccess { OrderLoadedSuccess My Order Id is: ${order.orderId} }';
}

class OrderError extends OrderState {
  final Exception errorMessage;
  OrderError({this.errorMessage});

  @override
  List<Object> get props => [errorMessage];
  @override
  String toString() => 'OrderError { OrderError: $errorMessage }';
}
