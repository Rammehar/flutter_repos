import 'package:equatable/equatable.dart';

import '../../models/order_model.dart';

abstract class OrderEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class SaveOrder extends OrderEvent {
  final Order order;
  SaveOrder({this.order});
  @override
  List<Object> get props => [order];
}
