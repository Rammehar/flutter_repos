import '../../models/category_model.dart';
import 'package:equatable/equatable.dart';

abstract class CategoryState extends Equatable {
  CategoryState();

  @override
  List<Object> get props => [];
}

class CategoryLoadInProgress extends CategoryState {}

class CategoryLoadSuccess extends CategoryState {
  final List<Category> categories;
  CategoryLoadSuccess([this.categories]);

  @override
  List<Object> get props => [categories];
  @override
  String toString() => "CategoryLoadSuccess $categories";
}

class CategoryLoadFailure extends CategoryState {
  final Exception errorMessage;
  CategoryLoadFailure({this.errorMessage});

  @override
  List<Object> get props => [errorMessage];

  @override
  String toString() => "CatgoryLoadFailure{ message : $errorMessage}";
}
