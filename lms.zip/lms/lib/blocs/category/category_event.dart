import 'package:equatable/equatable.dart';

class CategoryEvent extends Equatable{
  CategoryEvent();
  @override
  List<Object> get props => [];

}

class CategoriesFetched extends CategoryEvent{}
