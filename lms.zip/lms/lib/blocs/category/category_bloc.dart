import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';

import '../../repositories/category_repository.dart';
import 'category.dart';

class CategoryBloc extends Bloc<CategoryEvent, CategoryState> {
  CategoryRepository categoryRepository;
  CategoryBloc({@required this.categoryRepository})
      : assert(categoryRepository != null),
        super(CategoryLoadInProgress());

  @override
  Stream<CategoryState> mapEventToState(event) async* {
    if (event is CategoriesFetched) {
      yield CategoryLoadInProgress();
      try {
        final categoryList = await categoryRepository.fetchCategories();
        yield CategoryLoadSuccess(categoryList);
      } catch (err) {
        yield CategoryLoadFailure(errorMessage: err);
      }
    }
  }
}
