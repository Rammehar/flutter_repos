import 'package:equatable/equatable.dart';

class DownloadTaskEvent extends Equatable {
  @override
  List<Object> get props => [];
}

//fetch all tasks from Flutter downloader sqflite table
class FetchTasks extends DownloadTaskEvent {}

class RequestDownload extends DownloadTaskEvent {}

class CancelDownload extends DownloadTaskEvent {}

class PauseDownload extends DownloadTaskEvent {}

class ResumeDownload extends DownloadTaskEvent {}

class RetryDownload extends DownloadTaskEvent {}

class OpenDownloadedFile extends DownloadTaskEvent {}

class Delete extends DownloadTaskEvent {}
