import 'package:bloc/bloc.dart';

import '../../blocs/download_task/download_task_event.dart';
import '../../blocs/download_task/download_task_state.dart';
import '../../repositories/downloadable_task_repository.dart';

class DownloadTaskBloc extends Bloc<DownloadTaskEvent, DownloadTaskState> {
  DownloadTaskBloc() : super(DownloadTaskInitialState());
  DownloadableTaskRepository downloadableTaskRepository =
      DownloadableTaskRepository();

  @override
  Stream<DownloadTaskState> mapEventToState(DownloadTaskEvent event) async* {
    if (event is FetchTasks) {
      final tasks = await downloadableTaskRepository.loadTasks();
      yield DownloadTasksLoadedState(downloadableTask: tasks);
    }
  }
}
