import 'package:equatable/equatable.dart';

import '../../models/download_task.dart';

class DownloadTaskState extends Equatable {
  @override
  List<Object> get props => [];
}

class DownloadTaskInitialState extends DownloadTaskState {}

class DownloadTasksLoadedState extends DownloadTaskState {
  final List<TaskInfo> downloadableTask;
  DownloadTasksLoadedState({this.downloadableTask});
  @override
  List<Object> get props => [downloadableTask];
}
