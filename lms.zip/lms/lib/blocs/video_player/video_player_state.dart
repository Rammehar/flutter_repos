import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import 'package:video_player/video_player.dart';

abstract class VideoPlayerState extends Equatable {
  @override
  List<Object> get props => [];
}

class InitialVideo extends VideoPlayerState {}

class VideoLoadedSuccess extends VideoPlayerState {
  final VideoPlayerController videoPlayerController;
  VideoLoadedSuccess({@required this.videoPlayerController});
  @override
  List<Object> get props => [videoPlayerController];

  @override
  String toString() => 'VideoLoadedSuccess { VideoLoadedSuccess: $videoPlayerController }';
}
