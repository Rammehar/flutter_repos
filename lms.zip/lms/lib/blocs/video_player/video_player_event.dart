import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';
import 'package:video_player/video_player.dart';

abstract class VideoPlayerEvent extends Equatable {
  const VideoPlayerEvent();

  @override
  List<Object> get props => [];
}

class InitializedFirstVideo extends VideoPlayerEvent {}

class UpdateVideo extends VideoPlayerEvent {
  final VideoPlayerController videoPlayerController;
  UpdateVideo({@required this.videoPlayerController});

  @override
  List<Object> get props => [videoPlayerController];
  @override
  String toString() => 'UpdateVideo { UpdateVideo: $videoPlayerController }';
}
