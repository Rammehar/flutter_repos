import 'package:bloc/bloc.dart';
import 'package:video_player/video_player.dart';
import './video_player.dart';

class VideoPlayerBloc extends Bloc<VideoPlayerEvent, VideoPlayerState> {
  VideoPlayerBloc() : super(InitialVideo());
  @override
  Stream<VideoPlayerState> mapEventToState(VideoPlayerEvent event) async* {
//      if(event is InitializedFirstVideo) {
//        var firstVideo = VideoPlayerController.network("");
//        yield(VideoLoadedSuccess(videoPlayerController: firstVideo));
//      }
    if (event is UpdateVideo) {
      yield (VideoLoadedSuccess(
          videoPlayerController: event.videoPlayerController));
    }
  }

  @override
  Future<void> close() {
    return super.close();
  }
}
