part of 'password_reset_bloc.dart';

class PasswordResetFormState extends Equatable {
  final Email email;
  final FormzStatus status;
  final String serverResponse;

  const PasswordResetFormState({
    this.email = const Email.pure(),
    this.status = FormzStatus.pure,
    this.serverResponse,
  });

  PasswordResetFormState copyWith({
    Email email,
    FormzStatus status,
    String serverResponse,
  }) {
    return PasswordResetFormState(
      email: email ?? this.email,
      status: status ?? this.status,
      serverResponse: serverResponse ?? this.serverResponse,
    );
  }

  @override
  List<Object> get props => [email, status, serverResponse];

  @override
  bool get stringify => true;
}
