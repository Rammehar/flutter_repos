import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';
import 'package:formz/formz.dart';

import './models/email_model.dart';
import '../../repositories/password_reset_repository.dart';

part 'password_reset_event.dart';
part 'password_reset_state.dart';

class PasswordResetBloc
    extends Bloc<PasswordResetEvent, PasswordResetFormState> {
  final PasswordResetRepository passwordResetRepository;

  PasswordResetBloc({@required this.passwordResetRepository})
      : super(PasswordResetFormState());

  @override
  Stream<PasswordResetFormState> mapEventToState(
      PasswordResetEvent event) async* {
    if (event is EmailChanged) {
      final email = Email.dirty(event.email);
      yield state.copyWith(
        email: email,
        status: Formz.validate([email]),
      );
    } else if (event is PasswordRestButtonClicked) {
      if (state.status.isValidated) {
        try {
          yield state.copyWith(status: FormzStatus.submissionInProgress);
          final response = await passwordResetRepository
              .sendPasswordResetEmail(state.email.value);
          yield state.copyWith(
              status: FormzStatus.submissionSuccess, serverResponse: response);
        } on Exception catch (e) {
          yield state.copyWith(
              status: FormzStatus.submissionFailure,
              serverResponse: e.toString());
        }
      }
    }
  }
}
