import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';

import '../../models/course_model.dart';

class HomeTabState extends Equatable {
  HomeTabState();
  @override
  List<Object> get props => [];
}

class Initial extends HomeTabState {}

class Loading extends HomeTabState {}

class HomeTabContentsLoaded extends HomeTabState {
  final List<Course> courses;
  final List<Course> newCourses;
  final catList;
  HomeTabContentsLoaded({this.courses, this.catList, this.newCourses});
  @override
  List<Object> get props => [courses, catList, newCourses];
  @override
  String toString() =>
      'HomeTabContentsLoaded { HomeTabContentsLoaded: $courses }';
}

class Failure extends HomeTabState {
  final Exception errorMessage;
  Failure({@required this.errorMessage});
  @override
  List<Object> get props => [errorMessage];
  @override
  String toString() => 'HomeTabState { message: $errorMessage }';
}
