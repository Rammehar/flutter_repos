import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';

import '../../repositories/category_repository.dart';
import '../../repositories/courses_repository.dart';
import 'home_tab.dart';

class HomeTabBloc extends Bloc<HomeTabEvent, HomeTabState> {
  final CoursesRepository coursesRepository;

  final CategoryRepository categoryRepository;
  HomeTabBloc({@required this.coursesRepository, this.categoryRepository})
      : assert(coursesRepository != null),
        assert(categoryRepository != null),
        super(Loading());

  @override
  Stream<HomeTabState> mapEventToState(HomeTabEvent event) async* {
    if (event is FetchedHomeTabContents) {
      yield Loading();
      try {
        var courses = await coursesRepository.fetchCourses(event.user);
        var newCourses = await coursesRepository.fetchNewCourses(event.user);
        var categoriesList = await categoryRepository.fetchCategories();

        yield HomeTabContentsLoaded(
            courses: courses, catList: categoriesList, newCourses: newCourses);
      } catch (err) {
        yield Failure(errorMessage: err);
      }
    }
  }
}
