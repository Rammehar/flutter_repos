import 'package:equatable/equatable.dart';

import '../../models/user_model.dart';

class HomeTabEvent extends Equatable {
  HomeTabEvent();
  @override
  List<Object> get props => [];
}

class FetchedHomeTabContents extends HomeTabEvent {
  final User user;
  FetchedHomeTabContents({this.user});
  @override
  List<Object> get props => [user];
}
