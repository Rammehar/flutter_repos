import 'package:equatable/equatable.dart';

import '../../models/intro_model.dart';

abstract class IntroState extends Equatable {
  const IntroState();

  @override
  List<Object> get props => [];
}

class IntroLoadInProgress extends IntroState {}

class IntroLoadSuccess extends IntroState {
  final List<Intro> introPages;
  IntroLoadSuccess([this.introPages]);

  @override
  List<Object> get props => [introPages];

  @override
  String toString() => 'IntroLoadSuccess { settings: $introPages }';
}

class IntroLoadFailure extends IntroState {
  final Exception errorMessage;
  IntroLoadFailure({this.errorMessage});
  @override
  List<Object> get props => [errorMessage];
  @override
  String toString() => 'IntroLoadFailure { IntroLoadFailure: $errorMessage }';
}
