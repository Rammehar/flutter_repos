import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';

import '../../blocs/intro/intro.dart';
import '../../repositories/intro_repository.dart';

class IntroBloc extends Bloc<IntroEvent, IntroState> {
  IntroRepository introRepository;
  IntroBloc({@required this.introRepository})
      : assert(introRepository != null),
        super(IntroLoadInProgress());

  @override
  Stream<IntroState> mapEventToState(IntroEvent event) async* {
    if (event is GetIntro) {
      yield* _mapIntroLoadedToState();
    }
  }

  Stream<IntroState> _mapIntroLoadedToState() async* {
    try {
      final introList = await introRepository.fetchIntroPages();
      yield IntroLoadSuccess(introList);
    } catch (err) {
      yield IntroLoadFailure(errorMessage: err);
    }
  }
}
