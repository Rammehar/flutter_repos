import 'package:bloc/bloc.dart';
import '../../models/bottom_navigation_tab.dart';
import './bottomTab_event.dart';

class BottomTabBloc extends Bloc<BottomTabEvent, BottomNavigationTab> {
  BottomTabBloc() : super(BottomNavigationTab.courses);

  @override
  Stream<BottomNavigationTab> mapEventToState(BottomTabEvent event) async* {
    if (event is UpdateBottomTabEvent) {
      yield event.tab;
    }
  }
}
