import '../../models/bottom_navigation_tab.dart';
import 'package:equatable/equatable.dart';

abstract class BottomTabEvent extends Equatable {
  const BottomTabEvent();
}

class UpdateBottomTabEvent extends BottomTabEvent {

  final BottomNavigationTab tab;

  UpdateBottomTabEvent(this.tab);

  @override
  List<Object> get props => [tab];

  @override
  String toString() => 'UpdateTab { tab: $tab }';

}

