import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';

import '../../models/course_model.dart';

abstract class MyCoursesState extends Equatable {
  const MyCoursesState();

  @override
  List<Object> get props => [];
}

class MyCoursesLoadInProgress extends MyCoursesState {}

class MyCoursesLoadSuccess extends MyCoursesState {
  final List<Course> myCourses;
  MyCoursesLoadSuccess([this.myCourses]);
  @override
  List<Object> get props => [myCourses];
  @override
  String toString() => 'MyCoursesLoadSuccess { settings: $myCourses }';
}

class MyCoursesLoadFailure extends MyCoursesState {
  final Exception errorMessage;
  MyCoursesLoadFailure({@required this.errorMessage});
  @override
  List<Object> get props => [errorMessage];
  @override
  String toString() => 'MyCoursesLoadFailure { message: $errorMessage }';
}
