import 'package:flutter/material.dart';
import 'package:bloc/bloc.dart';
import '../../models/user_model.dart';
import '../../repositories/mycourses_repository.dart';
import './my_courses_event.dart';
import './my_courses_state.dart';

class MyCoursesBloc extends Bloc<MyCoursesEvent, MyCoursesState> {
  MyCoursesRepository myCoursesRepository;
  User user;

  MyCoursesBloc({@required this.myCoursesRepository, this.user})
      : assert(myCoursesRepository != null),
        assert(user != null),
        super(MyCoursesLoadInProgress());

  @override
  Stream<MyCoursesState> mapEventToState(MyCoursesEvent event) async* {
    if (event is MyCoursesFetched) {
      yield* _mapMyCoursesLoadedToState();
    }
    if (event is MyCourseRefreshRequested) {
      yield* _mapMyCoursesLoadedToState();
    }
  }

  Stream<MyCoursesState> _mapMyCoursesLoadedToState() async* {
    try {
      yield MyCoursesLoadInProgress();
      final myCoursesList =
          await myCoursesRepository.fetchCoursesByStudent(user.userId);
      if (myCoursesList.isEmpty) print("Empty list");
      yield MyCoursesLoadSuccess(myCoursesList);
    } catch (err) {
      yield MyCoursesLoadFailure(errorMessage: err);
    }
  }
}
