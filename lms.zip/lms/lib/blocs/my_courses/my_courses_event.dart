import 'package:equatable/equatable.dart';

abstract class MyCoursesEvent extends Equatable {
  const MyCoursesEvent();

  @override
  List<Object> get props => [];
}

class MyCoursesFetched extends MyCoursesEvent {}

class MyCourseRefreshRequested extends MyCoursesEvent {}
