part of 'login_bloc.dart';

abstract class LoginState extends Equatable {
  const LoginState();
  @override
  List<Object> get props => [];
}

class LoginInitial extends LoginState {}

class LoginSuccess extends LoginState {}

class LoginLoading extends LoginState {}

class LoginFailure extends LoginState {
  final String error;
  const LoginFailure({@required this.error});
  @override
  List<Object> get props => [error];
  @override
  String toString() => 'Login Failure {error: $error}';
}

class AuthFromGoogleSuccess extends LoginState {
  final User user;
  const AuthFromGoogleSuccess(this.user);
  @override
  List<Object> get props => [user];
  @override
  String toString() => 'AuthFromGoogleSuccess {AuthFromGoogleSuccess: $user}';
}

class AuthFromGoogleFailure extends LoginState {
  final String error;
  const AuthFromGoogleFailure({@required this.error});
  @override
  List<Object> get props => [error];
  @override
  String toString() => 'AuthFromGoogleFailure {error: $error}';
}
