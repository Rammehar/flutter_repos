import 'package:equatable/equatable.dart';

import '../../models/settings_model.dart';

abstract class SettingState extends Equatable {
  const SettingState();
  @override
  List<Object> get props => [];
}

class SettingLoadInProgress extends SettingState {}

class SettingLoadSuccess extends SettingState {
  final SettingModel settings;
  SettingLoadSuccess([this.settings]);

  @override
  List<Object> get props => [settings];
  @override
  String toString() => 'SettingLoadSuccess { settings: $settings }';
}

class SettingLoadFailure extends SettingState {}
