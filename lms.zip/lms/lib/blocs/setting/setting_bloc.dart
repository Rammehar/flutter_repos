import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';

import '../../blocs/setting/setting_event.dart';
import '../../blocs/setting/setting_state.dart';
import '../../repositories/setting_repository.dart';

class SettingBloc extends Bloc<SettingEvent, SettingState> {
  final SettingRepository settingRepository;

  SettingBloc({@required this.settingRepository})
      : assert(settingRepository != null),
        super(SettingLoadInProgress());

  @override
  Stream<SettingState> mapEventToState(SettingEvent event) async* {
    if (event is GetSetting) {
      yield* _mapSettingsLoadedToState();
    }
  }

  Stream<SettingState> _mapSettingsLoadedToState() async* {
    try {
      final settings = await this.settingRepository.fetchSettings();
      yield SettingLoadSuccess(settings);
    } catch (err) {
      print(err);
      yield SettingLoadFailure();
    }
  }
}
