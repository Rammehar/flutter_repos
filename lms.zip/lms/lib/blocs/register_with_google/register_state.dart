import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';
abstract class RegisterWithGoogleState extends Equatable{
  const RegisterWithGoogleState();
  @override
  List<Object> get props =>[];
}
class RegisterInitial extends RegisterWithGoogleState{}
class RegisterLoading extends RegisterWithGoogleState{}
class RegisterSuccess extends RegisterWithGoogleState{
    final String message;
    RegisterSuccess(this.message);
    @override
    List<Object> get props =>[message];
    @override
    String toString() => 'RegisterSuccess {RegisterSuccess: $message}';
}
class RegisterFailure extends RegisterWithGoogleState{
  final String error;
  const RegisterFailure({@required this.error});
  @override
  List<Object> get props=>[error];
  @override
  String toString() => 'RegisterFailure {error: $error}';
}




