import 'package:equatable/equatable.dart';

import '../../models/user_model.dart';

abstract class RegisterWithGoogleEvent extends Equatable {
  const RegisterWithGoogleEvent();
}

class RegisterWithGoogleButtonPressed extends RegisterWithGoogleEvent {
  final User user;
  RegisterWithGoogleButtonPressed(this.user);
  @override
  List<Object> get props => [user];
}
