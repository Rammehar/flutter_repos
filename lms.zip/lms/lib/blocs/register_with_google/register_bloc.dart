import 'dart:async';
import '../../repositories/user_repository.dart';
import 'package:meta/meta.dart';
import 'package:bloc/bloc.dart';
import 'register.dart';

class RegisterBloc
    extends Bloc<RegisterWithGoogleEvent, RegisterWithGoogleState> {
  final UserRepository userRepository;
  RegisterBloc({
    @required this.userRepository,
  })  : assert(userRepository != null),
        super(RegisterInitial());

  @override
  Stream<RegisterWithGoogleState> mapEventToState(
      RegisterWithGoogleEvent event) async* {
    if (event is RegisterWithGoogleButtonPressed) {
      yield RegisterLoading();
      try {
        final responseMessage = await userRepository.registerUser(event.user);
        yield RegisterSuccess(responseMessage);
      } catch (error) {
        yield RegisterFailure(error: error.toString());
      }
    }
  }
}
