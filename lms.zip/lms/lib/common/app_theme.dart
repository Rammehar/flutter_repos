import 'package:flutter/material.dart';
import './styles.dart';

enum AppTheme {
  LightTheme,
  DarkTheme,
}
final appThemeData = {
  AppTheme.LightTheme: ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: CustomColors.grayScaffoldColor,
    primaryColor: CustomColors.darkBlueColor,
    accentColor: CustomColors.lightBlueColor,
    fontFamily: "Montserrat",
    textTheme: TextTheme(
      headline5: TextStyle(
        fontFamily: "Montserrat-Bold",
        color: Colors.black54,
        // fontWeight: FontWeight.bold,
        fontSize: 16,
      ),
      headline6: TextStyle(
        fontFamily: "Montserrat-Bold",
        color: Colors.black,
        fontWeight: FontWeight.bold,
        fontSize: 17,
      ),
      headline4: TextStyle(
        fontFamily: "Montserrat",
        color: CustomColors.dartGrayColor,
        fontSize: 20,
        fontWeight: FontWeight.w600,
      ),
      bodyText1: TextStyle(
        fontFamily: "Montserrat-Bold",
        fontSize: 14,
      ),
      button: TextStyle(
        fontWeight: FontWeight.w600,
        color: CustomColors.whiteColor,
      ),
    ),
  ),
  AppTheme.DarkTheme: ThemeData(
    brightness: Brightness.dark,
    primaryColor: Colors.blue,
    fontFamily: "Montserrat",
    textTheme: TextTheme(),
  ),
};
