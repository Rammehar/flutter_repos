import 'hex_color.dart';

final bPrimaryColor = HexColor('29323c');
final bBlue = HexColor('21d4fd');
final bPruple = HexColor('b721ff');
final blightGrey = HexColor('313543');
final bwhiteGrey = HexColor('d8d8d8');
final bOrange = HexColor('fee140');
final bYellow = HexColor('fa709a');
final bGreen = HexColor('00c9ff');
final bBlue2 = HexColor('92fe9d');
final bLightOrange = HexColor('ffe29f');
final bLightRed = HexColor('ff719a');
final bLighOrange2 = HexColor('fbab66');
final bPurple = HexColor('f7418c');