import 'package:flutter/material.dart';

class InkWellButton extends StatelessWidget {
  final String text;
  final double height;
  Color color;
  final VoidCallback onTap;
  InkWellButton(
      {@required this.text,
      @required this.color,
      @required this.height,
      this.onTap});
  @override
  Widget build(BuildContext context) {
    return Material(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
      color: color,
      child: InkWell(
        borderRadius: BorderRadius.circular(50),
        onTap: onTap,
        child: Container(
          height: height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(50),
          ),
          alignment: Alignment.center,
          child: Text(
            '$text',
            style: Theme.of(context)
                .textTheme
                .headline6
                .copyWith(color: Colors.white),
          ),
        ),
      ),
    );
  }
}
