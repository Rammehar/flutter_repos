import 'package:flutter/material.dart';

// Custom Colors
class CustomColors {
  static final Color darkBlueColor = Color.fromRGBO(0, 47, 103, 1);
  static final Color lightBlueColor = Color.fromRGBO(24, 154, 211, 1);
  static final Color black38Color = Colors.black38;
  static final Color lightGreenColor = Color.fromRGBO(118, 255, 186, 1);
  static final Color dartGrayColor = Color.fromRGBO(37, 37, 37, 1);
  static final Color whiteColor = Colors.white;
  static final Color grayScaffoldColor = Color.fromRGBO(242, 247, 255, 1);
  static final Color categoryChipColor = Color.fromRGBO(214, 230, 255, 1);
  static final Color googleLoginButtonColor = Color.fromRGBO(234, 67, 53, 1);

  static final Gradient fabGradient = LinearGradient(
      colors: [darkBlueColor, lightBlueColor],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight);
}
