import 'package:flutter/material.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '.././blocs/feedback/feedback.dart';
import '.././blocs/feedback/feedback_bloc.dart';
import '.././common/normal_button.dart';
import '.././common/platform_alert_dialog.dart';
import '.././models/feedback_model.dart';

import '.././models/course_model.dart';
import '.././models/user_model.dart';

class FeedBackWidget extends StatelessWidget {
  final Course course;
  final User user;
  FeedBackWidget({this.user, this.course});
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FeedBackBloc, FeedBackState>(
      builder: (context, state) {
        if (state is FeedBackInitialState) {
          return course.isFeedBacked
              ? Container()
              : FlatButton(
                  onPressed: () {
                    showModelBottomSheetForRatting(context);
                  },
                  child: Text(
                    "Leave a Ratting",
                    style: Theme.of(context).textTheme.headline5.copyWith(
                          fontSize: 12,
                        ),
                  ),
                );
        }
        if (state is FeedBackLoadedState) {
          return state.feedback
              ? Container()
              : FlatButton(
                  onPressed: () {
                    showModelBottomSheetForRatting(context);
                  },
                  child: Text(
                    "Leave a Ratting",
                    style: Theme.of(context).textTheme.headline5.copyWith(
                          fontSize: 12,
                        ),
                  ),
                );
        }
        return Container();
      },
    );
  }

  showModelBottomSheetForRatting(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) {
        return FeedBackForm(
          courseId: course.courseId,
          userId: user.userId,
        );
      },
    );
  }
}

class FeedBackForm extends StatefulWidget {
  final courseId;
  final userId;
  FeedBackForm({this.courseId, this.userId});

  @override
  _FeedBackFormState createState() => _FeedBackFormState();
}

class _FeedBackFormState extends State<FeedBackForm> {
  double ratting;
  String message;
  bool _validate = false;
  final FocusNode _messageFocus = FocusNode();

  _saveRattingAndFeedBack() {
    setState(() {
      message == null ? _validate = true : _validate = false;
    });
    if (message != null && ratting != null) {
      FeedBack feedBack = FeedBack(
        userId: widget.userId,
        courseId: widget.courseId,
        message: message,
        ratting: ratting,
      );
      BlocProvider.of<FeedBackBloc>(context)
          .add(FeedBackAddEvent(feedBack: feedBack));
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<FeedBackBloc, FeedBackState>(
      listener: (context, state) async {
        if (state is FeedBackLoadedState) {
          print("Listener from FeedBackLoadedState");
          await PlatformAlertDialog(
            title: 'FeedBack Response',
            content: state.message,
            defaultActionText: 'OK',
          ).show(context);
          Navigator.of(context).pop();
        }
      },
      child: BlocBuilder<FeedBackBloc, FeedBackState>(
        builder: (context, state) {
          return SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    "How Would You Rate This Course ?",
                    style: Theme.of(context).textTheme.headline6,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Select Ratting",
                    style: Theme.of(context).textTheme.headline5,
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  SmoothStarRating(
                    color: Colors.yellow[900],
                    rating: 0,
                    //isReadOnly: true,
                    size: 40,
                    filledIconData: Icons.star,
                    halfFilledIconData: Icons.star_half,
                    defaultIconData: Icons.star_border,
                    starCount: 5,
                    allowHalfRating: true,
                    spacing: 2.0,
                    onRated: (value) {
                      print("rating value -> $value");
                      ratting = value;
                      // print("rating value dd -> ${value.truncate()}");
                    },
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.7,
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: TextField(
                      onChanged: (String value) {
                        message = value;
                      },
                      textInputAction: TextInputAction.done,
                      onSubmitted: (value) {
                        _messageFocus.unfocus();
                      },
                      keyboardType: TextInputType.multiline,
                      maxLines: 5,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderSide: BorderSide(
                          color: Colors.grey[400],
                        )),
                        hintText: "Enter a Feedback",
                        errorText: _validate ? 'Value Can\'t Be Empty' : null,
                        hintStyle: Theme.of(context).textTheme.headline5,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.7,
                    child: NormalButton(
                      onPressed: state is! FeedBackLoadingState
                          ? _saveRattingAndFeedBack
                          : null,
                      child: state is FeedBackLoadingState
                          ? Text(
                              "Please Wait",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                  ),
                            )
                          : Text(
                              "Save",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                  ),
                            ),
                      color: Colors.blue[900],
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
