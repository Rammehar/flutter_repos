import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '.././blocs/favorite/favorite_bloc.dart';
import '.././blocs/favorite/favorite_state.dart';
import '../blocs/favorite/favorite_event.dart';
import '../models/course_model.dart';
import '../models/user_model.dart';

class FavoriteWidget extends StatelessWidget {
  final Course course;
  final User user;
  FavoriteWidget({this.user, this.course});
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FavoriteBloc, FavoriteState>(
      builder: (context, state) {
        if (state is FavoriteInitialState) {
          return ListTile(
            onTap: () {
              BlocProvider.of<FavoriteBloc>(context).add(FavoriteToggleEvent(
                  userId: user.userId,
                  courseId: course.courseId,
                  isFavorite: !course.isFavorite));
            },
            leading: Icon(Icons.star_border),
            title: Text(
              course.isFavorite ? "Add To Favorites" : "Remove From Favorites",
              style: Theme.of(context).textTheme.headline5,
            ),
          );
        }
        if (state is FavoriteLoadedState) {
          return ListTile(
            onTap: () {
              BlocProvider.of<FavoriteBloc>(context).add(FavoriteToggleEvent(
                  userId: user.userId,
                  courseId: course.courseId,
                  isFavorite: !state.isFavorite));
            },
            leading: Icon(Icons.star_border),
            title: Text(
              state.isFavorite ? "Add To Favorites" : "Remove From Favorites",
              style: Theme.of(context).textTheme.headline5,
            ),
          );
        }
        return Container();
      },
    );
  }
}
