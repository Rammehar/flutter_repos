import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '.././blocs/authentication/authentication.dart';
import '.././utils/global_navigator_key.dart';
import '../blocs/cart/cart.dart';
import '../blocs/cart_icon/cart_icon.dart';

class MyCartIconButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, state) {
        if (state is Authenticated) {
          return BlocProvider<CartIconBloc>(
            create: (context) => CartIconBloc(
              cartBloc: BlocProvider.of<CartBloc>(context),
            ),
            child: BuildCartIcon(),
          );
        }
        return FlatButton(
          onPressed: () {
            GlobalNavigatorKey.navigatorKey.currentState
                .pushReplacementNamed('/signin');
          },
          child: Text(
            "SIGN IN",
            style: Theme.of(context)
                .textTheme
                .bodyText1
                .copyWith(color: Colors.white),
          ),
        );
      },
    );
  }
}

class BuildCartIcon extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CartIconBloc, CartIconState>(
      buildWhen: (previous, current) => previous != current,
      builder: (context, state) {
        if (state is LoadedTotalItemsInCart) {
          return Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                onPressed: () {
                  GlobalNavigatorKey.navigatorKey.currentState
                      .pushNamed('/cart-detail');
                },
                icon: Icon(
                  Icons.shopping_cart,
                  size: 25,
                  color: Colors.white,
                ),
              ),
              state.totalCourseInCart > 0
                  ? Positioned(
                      top: 7,
                      child: CircleAvatar(
                        radius: 8,
                        child: Text(
                          '${state.totalCourseInCart}',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        backgroundColor: Colors.red,
                      ))
                  : Container(),
            ],
          );
        }
        return Container();
      },
    );
  }
}
