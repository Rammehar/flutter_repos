import 'package:flutter/material.dart';

class ExpandableText extends StatefulWidget {
  ExpandableText(this.text);

  final String text;

  @override
  _ExpandableTextState createState() => _ExpandableTextState();
}

class _ExpandableTextState extends State<ExpandableText>
    with TickerProviderStateMixin<ExpandableText> {
  bool isExpanded = false;
  @override
  Widget build(BuildContext context) {
    return Column(children: <Widget>[
      AnimatedSize(
          vsync: this,
          duration: const Duration(milliseconds: 500),
          child: ConstrainedBox(
              constraints: isExpanded
                  ? BoxConstraints()
                  : BoxConstraints(maxHeight: 70.0),
              child: Text(
                widget.text,
                softWrap: true,
                overflow: TextOverflow.fade,
              ))),
      FlatButton(
          child: isExpanded ? Text("Show Less") : const Text('Show More'),
          onPressed: () {
            setState(() {
              if (isExpanded) {
                ConstrainedBox(constraints: BoxConstraints());
                isExpanded = false;
              } else {
                BoxConstraints(maxHeight: 70.0);
                isExpanded = true;
              }
            });
          })
    ]);
  }
}
