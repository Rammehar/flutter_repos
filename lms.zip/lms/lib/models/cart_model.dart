import 'course_model.dart';

class Cart {
  String cartId;
  int totalCourses;
  double totalCost;
  List<Course> courses;
  Cart({this.cartId, this.courses, this.totalCost, this.totalCourses});

  Cart.fromJson(Map<String, dynamic> json) {
    totalCourses = int.parse(json['totalcourse'].toString());
    totalCost = double.parse(json['totalcost'].toString());
    if (json['course'] != null) {
      var list = json['course'] as List;
      List<Course> coursesList = list.map((i) => Course.fromJson(i)).toList();
      courses = coursesList;
    }
  }

  Map<String, dynamic> toJson() => {
        "totalCourses": totalCourses,
        "totalCost": totalCost,
        "courses": courses.map((course) => course.toJson())
      };
  @override
  String toString() => "totalCourses: $totalCourses, totalCost:$totalCost";
}
