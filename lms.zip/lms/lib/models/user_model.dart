class User {
  String userId;
  String userName;
  String emailId;
  String phoneNo;
  String imageUrl;
  String password;
  String tokenId;

  User({
    this.userId,
    this.userName,
    this.emailId,
    this.phoneNo,
    this.password,
    this.imageUrl,
    this.tokenId,
  });

  User.fromJson(Map<String, dynamic> json) {
    userId = json['_id'];
    userName = json['name'];
    emailId = json['userid'];
    tokenId = json['tokenid'];
    imageUrl = json['photourl'];
    phoneNo = json['phone'];
  }
  @override
  String toString() =>
      'userid: $userId, email: $emailId, name: $userName, phone:$phoneNo, pass: $password image: $imageUrl';
}
