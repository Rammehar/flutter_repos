import '../models/user_model.dart';
import 'course_model.dart';

class Order {
  String orderId;
  String userId;
  List<Course> courses;
  User user;
  double totalAmount;
  Order({
    this.userId,
    this.courses,
    this.orderId,
    this.totalAmount,
    this.user,
  });

  Map<String, dynamic> toJson() => {
        "userid": userId,
        "totalAmount": totalAmount,
        "courses": courses.map((course) => course.toJson()).toList()
      };
  Order.fromJson(Map<String, dynamic> json) {
    totalAmount = double.parse(json['totalAmount'].toString());
    orderId = json['_id'];
    userId = json['userid'];
    user = User.fromJson(json['user']);

    if (json['cartContent'] != null) {
      var list = json['cartContent'] as List;
      List<Course> coursesList = list.map((i) => Course.fromJson(i)).toList();
      courses = coursesList;
    }
  }
}
