import 'package:flutter_downloader/flutter_downloader.dart';

import 'section_model.dart';

class TaskInfo {
  String taskId;
  String name;
  String link;
  int progress = 0;
  DownloadTaskStatus status = DownloadTaskStatus.undefined;
  final String sectionName;
  final Content content;

  TaskInfo({this.name, this.link, this.content, this.sectionName});

  @override
  String toString() =>
      'taskId: $taskId, name: $name, url:$link, status: $status progress: $progress';
}
