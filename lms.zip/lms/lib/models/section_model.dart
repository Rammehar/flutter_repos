import 'package:flutter/foundation.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'download_task.dart';

class Section {
  @required
  String sectionId;
  @required
  String sectionName;
  @required
  String duration;
  List<Content> contents;

  Section({
    this.sectionId,
    this.sectionName,
    this.duration,
    this.contents,
  });

  Section.fromJson(Map<String, dynamic> parsedJson) {
    sectionId = parsedJson['_id'];
    sectionName = parsedJson['name'];
    duration = parsedJson['duration'];
    //assign contents if not null
    if (parsedJson['contents'] != null) {
      var list = parsedJson['contents'] as List;
      List<Content> contentsList = list.map((content) {
        return Content.fromJson(content);
      }).toList();
      contents = contentsList;
    }
  }
}

class Content {
  int serialNo;
  @required
  String contentId;
  @required
  String videoName;
  @required
  String videoUrl;
  @required
  String mpdUrl;
  String duration;
  String isPaid;
  //TaskInfo taskInfo;

  Content({
    this.serialNo,
    this.contentId,
    this.videoName,
    this.videoUrl,
    this.mpdUrl,
    this.duration,
    this.isPaid,
    // this.taskInfo,
  });

  factory Content.fromJson(Map<String, dynamic> parsedJson) {
    return Content(
      contentId: parsedJson['_id'],
      serialNo: parsedJson['serialNo'],
      videoName: parsedJson['videoName'],
      videoUrl: parsedJson['videoURL'],
      mpdUrl: parsedJson['MPDvideo'],
      isPaid: parsedJson['paid'],
      duration: parsedJson['duration'].toString(),
      // taskInfo: TaskInfo.fromJson(parsedJson),
    );
  }
}
