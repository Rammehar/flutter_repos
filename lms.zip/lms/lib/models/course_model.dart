import 'section_model.dart';

class Course {
  String courseId;
  String name;
  String description;
  String author;
  String price;
  String imageUrl;
  bool purchased;
  bool isFavorite;
  bool isFeedBacked;
  String skills;
  String outcome;
  double ratings;
  List<Section> sections;

  Course({
    this.courseId,
    this.name,
    this.description,
    this.author,
    this.price,
    this.imageUrl,
    this.purchased,
    this.isFavorite,
    this.ratings,
    this.isFeedBacked,
    this.sections,
  });

  Map<String, dynamic> toJson() => {"courseId": courseId};

  Course.fromJson(Map<String, dynamic> json) {
    courseId = json['_id'];
    name = json['name'];
    description = json['description'];
    outcome = json['outcome'];
    skills = json['skills'];
    author = json['authorname'];
    ratings = double.parse(json['ratings'].toString());
    price = json['cost'].toString();
    imageUrl = json['imageurl'];

    if (json['purchased'] != null) {
      purchased = json['purchased'];
    }
    if (json['favourite'] != null) {
      isFavorite = json['favourite'];
    }
    if (json['feedback'] != null) {
      isFeedBacked = json['feedback'];
    }

    //assign sections if not null
    if (json['sections'] != null) {
      var list = json['sections'] as List;
      List<Section> sectionsList =
          list.map((i) => Section.fromJson(i)).toList();
      sections = sectionsList;
    }
  }

  @override
  String toString() =>
      'id: $courseId, name: $name, price:$price, des: $description author: $author';
}
