class Intro {
  String introId;
  String pageNo;
  String title;
  String description;
  String url;

  Intro(
      {String introId,
      String title,
      String pageNo,
      String description,
      String url}) {
    this.introId = introId;
    this.title = title;
    this.description = description;
    this.url = url;
  }

  Intro.fromJson(Map<String, dynamic> json) {
    introId = json['_id'];
    url = json['URL'];
    title = json['title'];
    description = json['description'];
    pageNo = json['pageNo'];
  }

//  Map<String, dynamic> toJson() {
//    final Map<String, dynamic> data = new Map<String, dynamic>();
//    data['introId'] = this.introId;
//    data['title'] = this.title;
//    data['description'] = this.description;
//    data['url'] = this.url;
//    return data;
//  }
}
