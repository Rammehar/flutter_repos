import 'package:flutter/material.dart';

enum BottomNavigationTab {
  courses,
  search,
  myCourses,
  account,
}

Map<BottomNavigationTab, GlobalKey<NavigatorState>> navigatorKeys = {
  BottomNavigationTab.courses: GlobalKey<NavigatorState>(),
  BottomNavigationTab.search: GlobalKey<NavigatorState>(),
  BottomNavigationTab.myCourses: GlobalKey<NavigatorState>(),
  BottomNavigationTab.account: GlobalKey<NavigatorState>(),
};
