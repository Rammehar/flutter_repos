class SettingModel {
  String settingId;
  String companyName;
  String address;
  int phoneNo;
  String logoUrl;

  SettingModel(
      {String settingId,
      String companyName,
      String address,
      int phoneNo,
      String logoUrl}) {
    this.settingId = settingId;
    this.companyName = companyName;
    this.address = address;
    this.phoneNo = phoneNo;
    this.logoUrl = logoUrl;
  }

  SettingModel.fromJson(Map<String, dynamic> json) {
//    settingId = json['settingId'];
//    companyName = json['companyName'];
//    address = json['address'];
//    phoneNo = json['phoneNo'];
//    logoUrl = json['logoUrl'];
    //settingId = json['userId'];
    companyName = json['title'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['settingId'] = this.settingId;
    data['companyName'] = this.companyName;
    data['address'] = this.address;
    data['phoneNo'] = this.phoneNo;
    data['logoUrl'] = this.logoUrl;
    return data;
  }
}
