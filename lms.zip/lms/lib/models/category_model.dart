import 'package:flutter/foundation.dart';

import '../models/course_model.dart';

class Category {
  @required
  String categoryId;
  @required
  String categoryName;
  @required
  String description;
  List<Course> courses;

  Category({
    this.categoryId,
    this.categoryName,
    this.description,
    this.courses,
  });

  Category.fromJson(Map<String, dynamic> json) {
    //print(json['name']);
    categoryId = json['_id'];
    categoryName = json['name'];
    description = json['description'];
    if (json['courses'] != null) {
      var list = json['courses'] as List;
      List<Course> coursesList = list.map((i) => Course.fromJson(i)).toList();
      courses = coursesList;
    }
  }
}
