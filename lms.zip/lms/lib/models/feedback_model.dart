class FeedBack {
  String courseId;
  String userId;
  String message;
  double ratting;
  FeedBack({this.courseId, this.userId, this.message, this.ratting});
}
