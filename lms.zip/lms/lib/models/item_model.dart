import 'section_model.dart';

class Item {
  String sectionName;
  Content content;
  String mpdUrl;
  Item({this.sectionName, this.content, this.mpdUrl});
}
