import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mylms/repositories/user_repository.dart';

import './blocs/authentication/authentication.dart';
import './blocs/bottom_tab/bottom_tab.dart';
import './blocs/category/category.dart';
import './blocs/favorite/favorite_bloc.dart';
import './blocs/feedback/feedback.dart';
import './blocs/password_reset/password_reset_bloc.dart';
import './blocs/simple_bloc_delegate.dart';
import './blocs/theme/theme_bloc.dart';
import './blocs/theme/theme_state.dart';
import './blocs/top_search_key/top_search_key_bloc.dart';
import './blocs/top_search_key/top_search_key_event.dart';
import './repositories/cart_repository.dart';
import './repositories/category_repository.dart';
import './repositories/favorite_repository.dart';
import './repositories/feedback_repository.dart';
import './repositories/order_repository.dart';
import './repositories/password_reset_repository.dart';
import './repositories/top_search_key_repository.dart';
import './route_generator.dart';
import './utils/global_navigator_key.dart';
import 'blocs/cart/cart_bloc.dart';
import 'blocs/cart/cart_event.dart';

const debug = true;
void main() async {
  // BlocSupervisor oversees Blocs and delegates to BlocDelegate.
  // We can set the BlocSupervisor's delegate to an instance of `SimpleBlocDelegate`.
  // This will allow us to handle all transitions and errors in SimpleBlocDelegate.
  //BlocSupervisor.delegate = SimpleBlocDelegate();
  Bloc.observer = SimpleBlocObserver();

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  //runZone useful if you want work with code that throw
  // unexpected exception in asynchronous operations
  runZoned(() {
    //SystemChrome.setEnabledSystemUIOverlays([]);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    runApp(
      MultiBlocProvider(
        providers: [
          BlocProvider<AuthenticationBloc>(
            create: (context) =>
                AuthenticationBloc(userRepository: UserRepository())
                  ..add(AppStarted()),
          ),
          BlocProvider<BottomTabBloc>(
            create: (context) => BottomTabBloc(),
          ),
          BlocProvider<ThemeBloc>(
            create: (context) => ThemeBloc(),
          ),
          BlocProvider<CategoryBloc>(
            create: (context) =>
                CategoryBloc(categoryRepository: CategoryRepository())
                  ..add(CategoriesFetched()),
          ),
          BlocProvider<TopSearchKeyBloc>(
            create: (context) => TopSearchKeyBloc(
                topSearchKeyRepository: TopSearchKeyRepository())
              ..add(TopSearchKeyFetched()),
          ),
          BlocProvider<PasswordResetBloc>(
            create: (context) => PasswordResetBloc(
                passwordResetRepository: PasswordResetRepository()),
          ),
        ],
        child: MyApp(),
      ),
    );
  }, onError: (dynamic error, dynamic stack) {
    print(error);
    print(stack);
  });
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ThemeBloc, ThemeState>(
      builder: (context, themeState) {
        return BlocBuilder<AuthenticationBloc, AuthenticationState>(
          builder: (context, state) {
            if (state is Authenticated) {
              return MultiBlocProvider(
                providers: [
                  BlocProvider<CartBloc>(
                    create: (context) => CartBloc(
                      cartRepository: CartRepository(),
                      orderRepository: OrderRepository(),
                    )..add(LoadCart(user: state.user)),
                  ),
                  BlocProvider<FeedBackBloc>(
                    create: (context) =>
                        FeedBackBloc(feedBackRepository: FeedBackRepository()),
                  ),
                  BlocProvider<FavoriteBloc>(
                    create: (context) =>
                        FavoriteBloc(favoriteRepository: FavoriteRepository()),
                  ),
                ],
                child: MaterialApp(
                  navigatorKey: GlobalNavigatorKey.navigatorKey,
                  debugShowCheckedModeBanner: false,
                  title: 'Skill Risers-LMS',
                  theme: themeState.themeData,
                  onGenerateRoute: RouteGenerator.generateRoute,
                ),
              );
            }
            return MaterialApp(
              navigatorKey: GlobalNavigatorKey.navigatorKey,
              debugShowCheckedModeBanner: false,
              title: 'Skill Risers-LMS',
              theme: themeState.themeData,
              onGenerateRoute: RouteGenerator.generateRoute,
            );
          },
        );
      },
    );
  }
}
