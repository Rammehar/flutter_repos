import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import './blocs/authentication/authentication.dart';
import './blocs/course_sections/course_sections.dart';
import './blocs/intro/intro.dart';
import './blocs/login/login_bloc.dart';
import './blocs/register_with_google/register_bloc.dart';
import './common/common.dart';
import './repositories/intro_repository.dart';
import './repositories/order_repository.dart';
import './repositories/section_repository.dart';
import './repositories/user_repository.dart';
import './screens/cart/cart_items_screen.dart';
import './screens/course_detail/course_detail_screen.dart';
import './screens/course_sections/my_course_sections_with_video_player.dart';
import './screens/home/home_screen.dart';
import './screens/intro/intro_screen.dart';
import './screens/login/change_password_screen.dart';
import './screens/login/login_screen.dart';
import './screens/login/password_reset_screen.dart';
import './screens/order/order_screen.dart';
import './screens/payment/payment_response_screen.dart';
import './screens/payment/payment_screen.dart';
import './utils/slide_route_transition.dart';
import 'blocs/order/order_bloc.dart';
import 'screens/course_detail/preview_player.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return SlideRightRoute(
            page: BlocBuilder<AuthenticationBloc, AuthenticationState>(
          builder: (context, state) {
            if (state is Authenticated) {
              return HomeScreen(user: state.user);
            }
            if (state is Unauthenticated) {
              return MultiBlocProvider(
                providers: [
                  BlocProvider<IntroBloc>(
                    create: (context) =>
                        IntroBloc(introRepository: IntroRepository())
                          ..add(GetIntro()),
                  ),
                ],
                child: IntroScreen(),
              );
            }
            return LoadingIndicator();
          },
        ));
      case '/browse':
        return SlideRightRoute(page: HomeScreen());
      case '/signin':
        var messageOfRegistration = settings.arguments;
        return SlideRightRoute(
          page: MultiBlocProvider(
            providers: [
              BlocProvider<LoginBloc>(
                create: (context) => LoginBloc(
                  userRepository: UserRepository(),
                  authenticationBloc:
                      BlocProvider.of<AuthenticationBloc>(context),
                ),
              ),
            ],
            child: LoginScreen(messageOfRegistration),
          ),
        );

      case '/password-reset':
        return SlideRightRoute(page: PasswordResetFormScreen());

      case '/my-course-sections':
        var courseId = settings.arguments;
        return SlideRightRoute(
            page: BlocBuilder<AuthenticationBloc, AuthenticationState>(
          builder: (context, state) {
            if (state is Authenticated) {
              var data = {"courseId": courseId, "userId": state.user.userId};
              return MultiBlocProvider(
                providers: [
                  BlocProvider<CourseSectionsBloc>(
                    create: (context) => CourseSectionsBloc(
                        sectionsRepository: SectionsRepository())
                      ..add(GetCourseSections(data)),
                  ),
                ],
                //child: CourseSectionsScreen(state.user),
                child: CourseSectionsContents(state.user),
              );
            }
            return IntroScreen();
          },
        ));
      case '/course-detail':
        var data = settings.arguments;
        return SlideRightRoute(
            page: MultiBlocProvider(
          providers: [
            BlocProvider<CourseSectionsBloc>(
              create: (context) =>
                  CourseSectionsBloc(sectionsRepository: SectionsRepository())
                    ..add(GetCourseSections(data)),
            ),
          ],
          child: CourseDetailScreen(),
        ));
      case '/preview-video':
        var videoUrl = settings.arguments;
        return SlideRightRoute(page: PreviewPlayer(url: videoUrl));
      case '/cart-detail':
        return SlideRightRoute(page: CartScreen());
      case '/checkout':
        var orderData = settings.arguments;
        return SlideRightRoute(
          page: BlocProvider<OrderBloc>(
            create: (context) => OrderBloc(
              orderRepository: OrderRepository(),
            ),
            child: OrderScreen(order: orderData),
          ),
        );
      case '/payment':
        var order = settings.arguments;
        return MaterialPageRoute(builder: (_) {
          return PaymentScreen(order);
        });
      case '/payment-response':
        var response = settings.arguments;
        return MaterialPageRoute(builder: (_) {
          return PaymentResponseScreen(responseData: response);
        });
      case '/register-with-google-detail':
        var user = settings.arguments;
        return MaterialPageRoute(builder: (_) {
          return BlocProvider<RegisterBloc>(
            create: (context) => RegisterBloc(userRepository: UserRepository()),
            child: ChangePasswordScreen(user),
          );
        });
      default:
        return _errorHandlingRoute();
    }
  }

  static Route<dynamic> _errorHandlingRoute() {
    return MaterialPageRoute(builder: (_) {
      return Scaffold(
        appBar: AppBar(
          title: Text("Error Page"),
        ),
        body: Center(
          child: Text("Error: Opps Something went Wrong!"),
        ),
      );
    });
  }
}
