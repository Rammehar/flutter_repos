import 'package:flutter/material.dart';

import '.././models/bottom_navigation_tab.dart';
import '.././screens/account/account_tab_contents.dart';
import '.././screens/home/category_courses_page.dart';
import '.././screens/home/home_page_contents.dart';
import '.././screens/mycourses/mycourses_tab_contents.dart';
import '.././screens/search/search_bar_tab_contents.dart';
import '../screens/home/all_courses_screen.dart';
import '../screens/home/categories_screen.dart';

class TabNavigator extends StatelessWidget {
  TabNavigator({
    this.tabItem,
    this.navigatorKey,
  });
  final BottomNavigationTab tabItem;
  final GlobalKey<NavigatorState> navigatorKey;

  @override
  Widget build(BuildContext context) {
    if (tabItem == BottomNavigationTab.courses) {
      return CoursesTabNavigation(
        navigatorKey: navigatorKey,
      );
    }
    if (tabItem == BottomNavigationTab.search) {
      return SearchTabNavigation(
        navigatorKey: navigatorKey,
      );
    }
    if (tabItem == BottomNavigationTab.myCourses) {
      return MyCoursesTabNavigation(
        navigatorKey: navigatorKey,
      );
    }
    if (tabItem == BottomNavigationTab.account) {
      return AccountTabNavigation(
        navigatorKey: navigatorKey,
      );
    }
    return Container();
  }
}

class CoursesTabNavigation extends StatelessWidget {
  final GlobalKey<NavigatorState> navigatorKey;
  CoursesTabNavigation({this.navigatorKey});
  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: navigatorKey,
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (context) {
              return HomeTabContents();
            });
          case '/categories':
            return MaterialPageRoute(builder: (context) {
              return CategoriesScreen();
            });

          case '/all-courses':
            return MaterialPageRoute(builder: (context) {
              return AllCoursesScreen();
            });
          case '/category-courses':
            final categoryId = settings.arguments;
            return MaterialPageRoute(builder: (context) {
              return CategoryCoursesPage(categoryId);
            });
        }
        return _errorHandlingRoute();
      },
    );
  }
}

class SearchTabNavigation extends StatelessWidget {
  final GlobalKey<NavigatorState> navigatorKey;
  SearchTabNavigation({this.navigatorKey});
  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: navigatorKey,
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (context) {
              return SearchBarTabContents();
            });
          case '/category-courses':
            final categoryId = settings.arguments;
            return MaterialPageRoute(builder: (context) {
              return CategoryCoursesPage(categoryId);
            });
        }
        return _errorHandlingRoute();
      },
    );
  }
}

class MyCoursesTabNavigation extends StatelessWidget {
  final GlobalKey<NavigatorState> navigatorKey;
  MyCoursesTabNavigation({this.navigatorKey});
  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: navigatorKey,
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (context) {
              return MyCoursesTabContents();
            });
        }
        return _errorHandlingRoute();
      },
    );
  }
}

class AccountTabNavigation extends StatelessWidget {
  final GlobalKey<NavigatorState> navigatorKey;
  AccountTabNavigation({this.navigatorKey});
  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: navigatorKey,
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (context) {
              return AccountTabContents();
            });
        }
        return _errorHandlingRoute();
      },
    );
  }
}

_errorHandlingRoute() {
  return MaterialPageRoute(builder: (_) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Error Page"),
      ),
      body: Center(
        child: Text("Error: Opps Something went Wrong!"),
      ),
    );
  });
}
