import 'package:flutter/material.dart';

class GlobalNavigatorKey {
  static final navigatorKey = GlobalKey<NavigatorState>();
}
