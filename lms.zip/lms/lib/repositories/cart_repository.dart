import 'dart:convert';

import '../models/cart_model.dart';
import '../models/user_model.dart';
import '../services/api_service.dart';

class CartRepository {
  ApiService _apiService = ApiService();

  Future<Cart> fetchCartItems(User user) async {
    print("$user");
    final response =
        await _apiService.get("cart/getcartdetails/${user.userId}", true);
    print("respository $response");
    return Cart.fromJson(response);
  }

  Future<Cart> addCourseToCart(courseId, userId) async {
    final Map data = {'courseid': courseId, 'userid': userId};
    //encode Map to JSON
    var body = json.encode(data);
    final response = await _apiService.post("cart/add", body, true);
    return Cart.fromJson(response);
  }

  Future<Cart> removeCourseFromCart(courseId, userId) async {
    final Map data = {'courseid': courseId, 'userid': userId};
    //encode Map to JSON
    var body = json.encode(data);
    final response = await _apiService.post("cart/removefromcart", body, true);
    return Cart.fromJson(response);
  }
}
