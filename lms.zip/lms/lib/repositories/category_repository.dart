import '.././models/category_model.dart';
import '../models/user_model.dart';
import '../services/api_service.dart';

class CategoryRepository {
  ApiService _apiService = ApiService();
  Future<List<Category>> fetchCategories() async {
    final response = await _apiService.get("category/getcategory", false);
    final res = response['category'];
    return res.map<Category>((json) => Category.fromJson(json)).toList();
  }

  Future<Category> fetchCoursesByCategoryId(categoryId, [User user]) async {
    String userid = user?.userId;
    String sufix = "";
    if (userid != null) {
      sufix = "?userid=$userid";
    }
    print("category course sufix is $categoryId$sufix");
    final response = await _apiService.get(
        "category/getcatcourses/$categoryId/$sufix", false);
    return Category.fromJson(response);
  }
}
