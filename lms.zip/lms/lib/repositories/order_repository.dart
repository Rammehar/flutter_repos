import 'dart:convert';

import '../models/order_model.dart';
import '../services/api_service.dart';

class OrderRepository {
  ApiService _apiService = ApiService();

  Future<Order> addOrder(Order order) async {
    var data = order.toJson();
    //encode Map to JSON
    var body = json.encode(data);
    final response = await _apiService.post("order/checkout", body, true);
    print('Response Data with Order id :-$response');

    return Order.fromJson(response);
  }
}
