import '../models/intro_model.dart';
import '../services/api_service.dart';

class IntroRepository {
  ApiService _apiService = ApiService();

  Future<List<Intro>> fetchIntroPages() async {
    final response = await _apiService.get("pages/getpageview", false);
    final pageViewList = response['result'];
    final res = pageViewList.cast<Map<String, dynamic>>();
    return res.map<Intro>((json) => Intro.fromJson(json)).toList();
  }
}
