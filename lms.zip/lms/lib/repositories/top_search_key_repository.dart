import '.././services/api_service.dart';

class TopSearchKeyRepository {
  ApiService _apiService = ApiService();

  Future<List<String>> fetchTopSearchKeys() async {
    List<String> searchKeys = [];
    final response = await _apiService.get("search/notsearched", false);
    for (var toSearchKey in response) {
      searchKeys.add(toSearchKey['key']);
    }
    return searchKeys;
  }
}
