import '../services/api_service.dart';

class PasswordResetRepository {
  ApiService _apiService = ApiService();

  Future<String> sendPasswordResetEmail(String email) async {
    final response = await _apiService.get("user/forgotpwd/$email", false);
    return response['message'];
  }
}
