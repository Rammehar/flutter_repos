import 'dart:async';

import '../models/settings_model.dart';
import '../services/api_service.dart';

class SettingRepository {
  ApiService _apiService = ApiService();
  Future<SettingModel> fetchSettings() async {
    final response = await _apiService.get("todos/1", false);
    return SettingModel.fromJson(response);
  }
}
