import 'dart:convert';
import '.././models/feedback_model.dart';
import '.././services/api_service.dart';

class FeedBackRepository {
  ApiService _apiService = ApiService();
  Future addFeedBack(FeedBack feedBack) async {
//    await Future.delayed(Duration(seconds: 2));
//    Map<String, dynamic> res = {
//      'message': "Thank You for Valuable FeedBack!",
//      'feedback': true
//    };
//    return res;

    final Map feedBackDetail = {
      'userid': feedBack.userId,
      'courseid': feedBack.courseId,
      'message': feedBack.message,
      'ratings': feedBack.ratting,
    };
    var body = json.encode(feedBackDetail);
    final response = await _apiService.post("feedback/addfeedback", body, true);
    return response;
  }
}
