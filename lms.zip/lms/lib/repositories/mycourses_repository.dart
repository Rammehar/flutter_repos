import '.././models/course_model.dart';
import '.././services/api_service.dart';

class MyCoursesRepository {
  ApiService _apiService = ApiService();

  Future<List<Course>> fetchCoursesByStudent(String userId) async {
    print(userId);
    final response = await _apiService.get("user/getusercourses/$userId", true);
    final coursesList = response;
    final res = coursesList.cast<Map<String, dynamic>>();
    return res.map<Course>((json) => Course.fromJson(json)).toList();
  }
}
