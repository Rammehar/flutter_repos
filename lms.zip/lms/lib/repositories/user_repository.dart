import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:meta/meta.dart';

import '.././helpers/device_info_helper.dart';
import '.././models/user_model.dart';
import '../services/api_service.dart';
import '../services/local_storage_service.dart';

class UserRepository {
  GoogleSignIn _googleSignIn = GoogleSignIn.standard();
  final _firebaseAuth = firebase_auth.FirebaseAuth.instance;
  ApiService _apiService = ApiService();
  LocalStorageService _localStorageService = LocalStorageService();
  DeviceInfoHelper deviceInfoHelper = DeviceInfoHelper();

  Future<User> logInWithGoogle() async {
    try {
      final googleUser = await _googleSignIn.signIn();
      final googleAuth = await googleUser.authentication;

      if (googleAuth.accessToken != null && googleAuth.idToken != null) {
        final credential = firebase_auth.GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken,
          idToken: googleAuth.idToken,
        );
        final uCredential =
            await _firebaseAuth.signInWithCredential(credential);
        final user = uCredential.user;
        return User(
            emailId: user.email,
            userName: user.displayName,
            imageUrl: user.photoURL,
            phoneNo: user.phoneNumber,
            password: "");
      } else {
        throw "Google Access Token Missing!";
      }
    } on Exception {
      throw "Server Error";
    }
  }

  Future<String> registerUser(User user) async {
    //======STORE GOOGLE DETAIL TO OUR DB=========
    final Map userDetail = {
      'userid': user.emailId,
      'name': user.userName,
      'phone': user.phoneNo,
      'password': user.password,
      'photourl': user.imageUrl
    };
    var body = json.encode(userDetail);
    print("Weldone");
    print(body);
    final response = await _apiService.post("user/adduser", body, false);
    print("Here we go...");
    print(response);
    return response['status'];
  }

  Future<User> authenticate(
      {@required String username, @required String password}) async {
    var hardware = "";
    var brand = "";
    if (Platform.isAndroid) {
      hardware = deviceInfoHelper.deviceInfo['hardware'];
      brand = deviceInfoHelper.deviceInfo['brand'];
    }
    if (Platform.isIOS) {
      hardware = deviceInfoHelper.deviceInfo['utsname.machine'];
      brand = deviceInfoHelper.deviceInfo['name'];
    }
    final Map credential = {
      'userid': username.trim().toLowerCase(),
      'password': password,
      'brand': brand,
      'deviceHardwareId': hardware
    };
    //encode Map to JSON
    var body = json.encode(credential);
    final response = await _apiService.post("user/loginuser", body, false);
    return User.fromJson(response);
  }

  Future<void> deleteToken(User user) async {
    _firebaseAuth.signOut();
    await _googleSignIn.signOut();
    await _localStorageService.removeFromLocalStorage('userData');
    return;
  }

  Future<void> persistToken(User user) async {
    final userData = json.encode({
      'token': user.tokenId,
      'userid': user.userId,
      'userName': user.userName,
      'emailId': user.emailId,
      'imageUrl': user.imageUrl
    });

    await _localStorageService.setMyString('userData', userData);
  }

  Future<bool> hasToken() async {
    return await _localStorageService.checkKeyExistsInLocalStorage('userData');
  }

  Future<User> getUserData() async {
    final userData = await _localStorageService.getMyString('userData');
    Map<String, Object> response = json.decode(userData);
    return User(
      userId: response['userid'],
      userName: response['userName'],
      tokenId: response['token'],
      emailId: response['emailId'],
      imageUrl: response['imageUrl'],
    );
  }
}
