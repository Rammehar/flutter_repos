import '.././models/course_model.dart';
import '../models/user_model.dart';
import '../services/api_service.dart';

class CoursesRepository {
  ApiService _apiService = ApiService();

  Future<List<Course>> fetchCourses([User user]) async {
    String userid = user?.userId;
    String sufix = "";
    if (userid != null) {
      sufix = "?userid=$userid";
    }
    print("sufix is $sufix");
    final response = await _apiService.get("course/getcourse$sufix", false);
    final coursesList = response;
    final res = coursesList.cast<Map<String, dynamic>>();
    return res.map<Course>((json) => Course.fromJson(json)).toList();
  }

  Future<List<Course>> searchCourses(String query, [User user]) async {
    String userid = user?.userId;
    String sufix = "";
    if (userid != null) {
      sufix = "&userid=$userid";
    }

    final response = await _apiService.get("search?key=$query$sufix", false);
    print(response);
    final coursesList = response;
    final res = coursesList.cast<Map<String, dynamic>>();
    return res.map<Course>((json) => Course.fromJson(json)).toList();
  }

  Future<List<Course>> fetchNewCourses([User user]) async {
    String userid = user?.userId;
    String sufix = "";
    if (userid != null) {
      sufix = "?userid=$userid";
    }
    final response = await _apiService.get("course/newcourse$sufix", false);
    final coursesList = response;
    final res = coursesList.cast<Map<String, dynamic>>();
    return res.map<Course>((json) => Course.fromJson(json)).toList();
  }
}
