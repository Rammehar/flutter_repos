import 'dart:convert';

import '.././services/api_service.dart';

class FavoriteRepository {
  ApiService _apiService = ApiService();

  Future<bool> updateIsFavoriteStatusOfCourse(event) async {
    print('toggle status is ${event.isFavorite} and ${event.courseId}');
    final Map favoriteDetail = {
      'userid': event.userId,
      'courseid': event.courseId,
    };
    var body = json.encode(favoriteDetail);
    final response = await _apiService.post("user/togglefavourite", body, true);

    return response['favourite'];
  }
}
