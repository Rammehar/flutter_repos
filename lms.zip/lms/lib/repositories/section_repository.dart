import 'dart:convert';
import '.././models/course_model.dart';
import '.././services/api_service.dart';

class SectionsRepository {
  ApiService _apiService = ApiService();

  Future<Course> fetchCourseWithSectionsByCourseId(myData) async {
    final Map data = {
      'courseid': myData["courseId"],
      'userid': myData["userId"],
    };
    //encode Map to JSON
    var body = json.encode(data);
    final response =
        await _apiService.post("section/getsectiondetails", body, false);

    int serialNo = 1;

    for (var section in response['sections']) {
      for (var content in section["contents"]) {
        content['serialNo'] = serialNo++;
      }
    }
    return Course.fromJson(response);
  }

  Future<void> updateIsFavoriteStatusOfCourse(event) async {
    print('toggle status is ${event.isFavorite} and ${event.courseId}');
    final Map favoriteDetail = {
      'userid': event.userId,
      'courseid': event.courseId,
    };
    var body = json.encode(favoriteDetail);
    await _apiService.post("user/togglefavourite", body, true);
  }
}
