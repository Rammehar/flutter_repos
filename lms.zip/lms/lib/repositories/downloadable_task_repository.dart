import 'package:flutter_downloader/flutter_downloader.dart';

import '../models/download_task.dart';

class DownloadableTaskRepository {
  Future<List<TaskInfo>> loadTasks() async {
    final tasks = await FlutterDownloader.loadTasks();
    return tasks
        .map((task) => TaskInfo(
              //taskId: task.taskId,
              name: task.filename,
              link: task.url,
              //progress: task.progress,
              // status: task.status,
            ))
        .toList();
  }
}
