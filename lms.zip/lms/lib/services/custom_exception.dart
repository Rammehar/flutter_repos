import 'package:dio/dio.dart';

class CustomException extends DioError {
  final _message;
  final _prefix;
  CustomException([this._message, this._prefix]);
  String toString() {
    return "$_prefix$_message";
  }
}

class MyOwnException extends CustomException {
  MyOwnException([String message]) : super(message, "");
}

class FetchDataException extends CustomException {
  FetchDataException([String message])
      : super(message, "Error During Communication");
}

class BadRequestException extends CustomException {
  BadRequestException([message]) : super(message, "Invalid Request");
}

class UnauthorizedException extends CustomException {
  UnauthorizedException([message]) : super(message, "Unauthorised:");
}

class InvalidInputException extends CustomException {
  InvalidInputException([String message]) : super(message, "Invalid Input:");
}
