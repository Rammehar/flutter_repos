import 'package:shared_preferences/shared_preferences.dart';

class LocalStorageService {
  SharedPreferences prefs;

  setMyString(key, [value]) async {
    prefs = await SharedPreferences.getInstance();
    prefs.setString(key, value);
  }

  Future<String> getMyString(key, [value]) async {
    prefs = await SharedPreferences.getInstance();
    return prefs.getString(key);
  }

  Future<bool> removeFromLocalStorage(key) async {
    prefs = await SharedPreferences.getInstance();
    return prefs.remove(key);
  }

  Future<bool> checkKeyExistsInLocalStorage(key)async{
    prefs = await SharedPreferences.getInstance();
    return  prefs.containsKey(key);
  }
}


//
//save(String key, dynamic value) async {
//  final SharedPreferences sharedPrefs = await SharedPreferences.getInstance();
//  if (value is bool) {
//    sharedPrefs.setBool(key, value);
//  } else if (value is String) {
//    sharedPrefs.setString(key, value);
//  } else if (value is int) {
//    sharedPrefs.setInt(key, value);
//  } else if (value is double) {
//    sharedPrefs.setDouble(key, value);
//  } else if (value is List<String>) {
//    sharedPrefs.setStringList(key, value);
//  }
//}
