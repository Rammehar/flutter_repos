import 'dart:async';
import 'dart:convert';

import 'package:connectivity/connectivity.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

import './custom_exception.dart';
import './http_interceptor.dart';
import 'connectivity_retry_request.dart';
import 'retry_interceptor.dart';

class ApiService {
  Dio dio = Dio(
    BaseOptions(
        //connectTimeout: 5000,
        //receiveTimeout: 5000,
        baseUrl: "https://www.skillrisers.com/"),
  );

  Future<dynamic> get(String uri, requiresToken) async {
    dio.transformer = FlutterTransformer();
    dio.interceptors.add(AppInterceptors());

    dio.interceptors.add(
      RetryOnConnectionChangeInterceptor(
        requestRetrier: DioConnectivityRequestRetrier(
          dio: Dio(),
          connectivity: Connectivity(),
        ),
      ),
    );

    if (requiresToken) {
      dio.options.headers['requires-token'] = requiresToken;
    }
    print('Api Get, uri $uri');
    var responseJson;
    try {
      final response = await dio.get(uri);
      responseJson = response.data;
    } on DioError catch (e) {
      throw _handleError(e);
    }
    print('api get received!');
    return responseJson;
  }

  Future<dynamic> post(String url, dynamic body, requiresToken) async {
    dio.transformer = FlutterTransformer();
    dio.interceptors.add(AppInterceptors());
    dio.interceptors.add(
      RetryOnConnectionChangeInterceptor(
        requestRetrier: DioConnectivityRequestRetrier(
          dio: Dio(),
          connectivity: Connectivity(),
        ),
      ),
    );

    dio.options.headers['content-Type'] = 'application/json';
    if (requiresToken) {
      print('token added');
      dio.options.headers['requires-token'] = requiresToken;
    }
    print('Api Post, url $url');
    var responseJson;
    try {
      final response = await dio.post(url, data: body);
      responseJson = response.data;
    } on DioError catch (e) {
      throw _handleError(e);
    }
    print('api post.');
    return responseJson;
  }

  dynamic _handleError(DioError error) {
    print("Error is :-$error");
    String errorDescription = "";
    if (error is DioError) {
      // DioError dioError = error as DioError;
      switch (error.type) {
        case DioErrorType.CANCEL:
          errorDescription = "Request to API server was cancelled";
          break;
        case DioErrorType.CONNECT_TIMEOUT:
          errorDescription = "Connection timeout with API server";
          break;
        case DioErrorType.DEFAULT:
          errorDescription = "Connection to API server failed!";
          break;
        case DioErrorType.RECEIVE_TIMEOUT:
          errorDescription = "Receive timeout in connection with API server";
          break;
        case DioErrorType.RESPONSE:
          errorDescription = "Message: ${error.response.data['message']}";
          break;
        case DioErrorType.SEND_TIMEOUT:
          errorDescription = "Send timeout in connection with API server";
          break;
      }
    } else {
      errorDescription = "Unexpected error occurred";
    }
    throw MyOwnException(errorDescription);
    //return errorDescription;
  }
}

class FlutterTransformer extends DefaultTransformer {
  FlutterTransformer() : super(jsonDecodeCallback: _parseJson);
}

// Must be top-level function
_parseAndDecode(String response) {
  return jsonDecode(response);
}

_parseJson(String text) {
  return compute(_parseAndDecode, text);
}
