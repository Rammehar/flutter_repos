import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '.././repositories/user_repository.dart';
import '.././utils/global_navigator_key.dart';
import '.././blocs/authentication/authentication.dart';
import './local_storage_service.dart';

class AppInterceptors extends Interceptor {
  LocalStorageService _localStorageService = LocalStorageService();
  AuthenticationBloc authBloc =
      AuthenticationBloc(userRepository: UserRepository());
  @override
  Future<dynamic> onRequest(RequestOptions options) async {
    bool isUserAvailable =
        await _localStorageService.checkKeyExistsInLocalStorage('userData');
    if (isUserAvailable) {
      final userData = await _localStorageService.getMyString('userData');
      Map<String, Object> res = json.decode(userData);
      var token = res['token'];
      options.headers.addAll({"tokenid": token});
    }
    print(options.headers);
    return options;
  }

  @override
  Future<dynamic> onResponse(Response options) async {
    return options;
  }

  @override
  Future<dynamic> onError(DioError err) async {
    print("<-- Error -->");
    if (err.response?.statusCode == 401) {
      bool isUserAvailable =
          await _localStorageService.checkKeyExistsInLocalStorage('userData');
      if (isUserAvailable) {
        authBloc.add(LoggedOut());
        await Future.delayed(Duration(microseconds: 200));
        GlobalNavigatorKey.navigatorKey.currentState
            .pushNamedAndRemoveUntil('/signin', ModalRoute.withName('/'));
      }
    }
    print(err.error);
    print(err.message);
    return super.onError(err);
  }
}
