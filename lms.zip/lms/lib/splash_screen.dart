import 'dart:async';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  void initState() {
    super.initState();
    //redirect to homeScreen after 3 seconds
    Timer(Duration(seconds: 13),
        () => Navigator.of(context).pushReplacementNamed('/'));
  }

  @override
  Widget build(BuildContext context) {
    //get specifications of current device
    var mediaQuery = MediaQuery.of(context).size;
    return
        //use SafeArea to prevent distortions due to notch and notification bar
        SafeArea(
      child: Scaffold(
        backgroundColor: Color(0xFF17172E),
        body: Column(
          children: <Widget>[
            Expanded(
              flex: 5,
              child: Container(
                width: mediaQuery.width,
                padding: EdgeInsets.all(5),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Text('Brain Mentors',
                        style: TextStyle(
                          fontSize: 50,
                          color: Colors.white,
                        )),
                    Text(
                      'LMS',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
                flex: 1,
                child: Column(
                  children: <Widget>[
                    CircularProgressIndicator(
                      backgroundColor: Colors.white,
                      strokeWidth: 3,
                    )
                  ],
                )),
          ],
        ),
      ),
    );
  }
}
