import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/intro/intro.dart';
import '../../common/common.dart';

class IntroScreen extends StatefulWidget {
  @override
  _IntroScreenState createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  PageController _pageController;
  int currentIndex = 0;
  var currentPageValue = 0.0;
  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: 0);
    _pageController.addListener(() {
      setState(() {
        currentPageValue = _pageController.page;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<IntroBloc, IntroState>(
      builder: (context, state) {
        if (state is IntroLoadSuccess) {
          final data = state.introPages;
          return Scaffold(
            body: SafeArea(
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  PageView.builder(
                    onPageChanged: (page) {
                      setState(() {
                        currentIndex = page;
                      });
                    },
                    physics: ClampingScrollPhysics(),
                    //dragStartBehavior: DragStartBehavior.down,
                    controller: _pageController,
                    itemCount: data.length,
                    itemBuilder: (context, position) {
                      if (position == currentPageValue.floor()) {
                        return Transform(
                          transform: Matrix4.identity()
                            ..rotateY(currentPageValue - position)
                            ..rotateZ(currentPageValue - position),
                          child: makePage(
                            title: data[position].title,
                            imageUrl: data[position].url,
                            description: data[position].description,
                            reverse: false,
                          ),
                        );
                      } else if (position == currentPageValue.floor() + 1) {
                        return Transform(
                          transform: Matrix4.identity()
                            ..rotateY(currentPageValue - position)
                            ..rotateZ(currentPageValue - position),
                          child: makePage(
                            title: data[position].title,
                            imageUrl: data[position].url,
                            description: data[position].description,
                            reverse: false,
                          ),
                        );
                      } else {
                        return makePage(
                          title: data[position].title,
                          imageUrl: data[position].url,
                          description: data[position].description,
                          reverse: false,
                        );
                      }
                    },
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: 60),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: _buildIndicator(data.length),
                    ),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Expanded(
                  child: Material(
                    color: Theme.of(context).primaryColor,
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).pushReplacementNamed('/browse');
                      },
                      child: Container(
                        height: 40,
                        alignment: Alignment.center,
                        child: Text(
                          "Browse",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1
                              .copyWith(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Material(
                    color: Theme.of(context).primaryColor,
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).pushNamed('/signin');
                      },
                      child: Container(
                        height: 40,
                        alignment: Alignment.center,
                        child: Text(
                          "SignIn",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1
                              .copyWith(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        }
        if (state is IntroLoadFailure) {
          return Scaffold(
            body: Center(
              child: Text("${state.errorMessage}"),
            ),
          );
        }
        return LoadingIndicator();
      },
    );
  }

  Widget makePage({title, imageUrl, description, reverse = false}) {
    return Container(
      padding: EdgeInsets.only(left: 50, right: 50, bottom: 60),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CachedNetworkImage(
            imageUrl: "$imageUrl",
            imageBuilder: (context, imageProvider) => Container(
              height: MediaQuery.of(context).size.height * 0.45,
              width: MediaQuery.of(context).size.width * 0.80,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: imageProvider,
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey,
                    blurRadius: 5.0,
                  ),
                ],
              ),
            ),
            placeholder: (context, url) => CircularProgressIndicator(),
            errorWidget: (context, url, error) => Icon(Icons.error),
          ),
          SizedBox(
            height: 50,
          ),
          Text(
            "$title",
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headline4,
          ),
          SizedBox(
            height: 20,
          ),
          Text(
            description,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headline5,
          )
        ],
      ),
    );
  }

  List<Widget> _buildIndicator(length) {
    List<Widget> indicators = [];
    for (int i = 0; i < length; i++) {
      if (currentIndex == i) {
        indicators.add(_indicator(true));
      } else {
        indicators.add(_indicator(false));
      }
    }

    return indicators;
  }

  Widget _indicator(bool isActive) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      height: 6,
      width: isActive ? 30 : 6,
      margin: EdgeInsets.only(right: 5),
      decoration: BoxDecoration(
          color: Theme.of(context).accentColor,
          borderRadius: BorderRadius.circular(5)),
    );
  }
}
