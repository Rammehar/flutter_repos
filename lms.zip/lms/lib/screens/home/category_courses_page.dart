import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import './courses_list.dart';
import '../../blocs/authentication/authentication.dart';
import '../../blocs/category_courses/category_courses.dart';
import '../../common/common.dart';
import '../../repositories/category_repository.dart';

class CategoryCoursesPage extends StatelessWidget {
  final categoryId;
  CategoryCoursesPage(this.categoryId) : assert(categoryId != null);
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, state) {
        if (state is Authenticated) {
          return MultiBlocProvider(
            providers: [
              BlocProvider<CategoryCoursesBloc>(
                create: (context) => CategoryCoursesBloc(
                    categoryRepository: CategoryRepository())
                  ..add(
                    CategoryCoursesFetched(
                        categoryId: categoryId, user: state.user),
                  ),
              ),
            ],
            child: LoadCategoryCourses(),
          );
        }
        return MultiBlocProvider(
          providers: [
            BlocProvider<CategoryCoursesBloc>(
              create: (context) =>
                  CategoryCoursesBloc(categoryRepository: CategoryRepository())
                    ..add(CategoryCoursesFetched(categoryId: categoryId)),
            ),
          ],
          child: LoadCategoryCourses(),
        );
      },
    );
  }
}

class LoadCategoryCourses extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CategoryCoursesBloc, CategoryCoursesState>(
      builder: (context, state) {
        if (state is CategoryCoursesLoadSuccess) {
          var category = state.categoryWithCourses;
          return Scaffold(
            appBar: AppBar(
              title: Text(
                "${category.categoryName}",
                style: Theme.of(context)
                    .textTheme
                    .headline6
                    .copyWith(color: Colors.white, fontSize: 18),
              ),
            ),
            body: SafeArea(
              child: CoursesList(courses: category.courses),
            ),
          );
        }
        if (state is CategoryCoursesLoadFailure) {
          return Scaffold(
            body: Center(
              child: Text("${state.errorMessage}"),
            ),
          );
        }
        return LoadingIndicator();
      },
    );
  }
}
