import 'package:flutter/material.dart';

import './course_widget.dart';
import '../../models/course_model.dart';

class CoursesList extends StatelessWidget {
  final List<Course> courses;
  CoursesList({this.courses});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          childAspectRatio: MediaQuery.of(context).size.height /
              (MediaQuery.of(context).size.width * 2.2),
          crossAxisCount: 3,
          crossAxisSpacing: 6,
          mainAxisSpacing: 6,
        ),
        itemBuilder: (context, index) {
          return CourseWidget(
            course: courses[index],
            maxLines: 2,
            starSize: 15,
          );
        },
        itemCount: courses.length,
      ),
    );

//    return ListView.builder(
//      itemCount: courses.length,
//      itemBuilder: (context, index) {
//        return CourseWidget(courses[index]);
//      },
//    );
  }
}
