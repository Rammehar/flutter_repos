import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/authentication/authentication.dart';
import '../../blocs/course/courses.dart';
import '../../common/common.dart';
import '../../repositories/courses_repository.dart';
import '../../widgets/my_cart_icon_button.dart';
import 'courses_list.dart';

class AllCoursesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, state) {
        if (state is Authenticated) {
          return BlocProvider<CoursesBloc>(
            create: (context) =>
                CoursesBloc(coursesRepository: CoursesRepository())
                  ..add(AllCoursesFetched(user: state.user)),
            child: BuildAllCourses(),
          );
        }
        return BlocProvider<CoursesBloc>(
          create: (context) =>
              CoursesBloc(coursesRepository: CoursesRepository())
                ..add(AllCoursesFetched()),
          child: BuildAllCourses(),
        );
      },
    );
  }
}

class BuildAllCourses extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CoursesBloc, CoursesState>(
      builder: (context, state) {
        if (state is CoursesLoadSuccess) {
          return Scaffold(
            appBar: AppBar(
              title: Text(
                "All Courses",
                style: Theme.of(context)
                    .textTheme
                    .headline6
                    .copyWith(color: Colors.white),
              ),
              actions: [
                MyCartIconButton(),
              ],
            ),
            body: SafeArea(
              child: CoursesList(
                courses: state.courses,
              ),
            ),
          );
        }
        return LoadingIndicator();
      },
    );
  }
}
