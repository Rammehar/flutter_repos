import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/authentication/authentication.dart';
import '../../blocs/home_tab/home_tab.dart';
import '../../common/common.dart';
import '../../common/styles.dart';
import '../../models/category_model.dart';
import '../../models/course_model.dart';
import '../../repositories/category_repository.dart';
import '../../repositories/courses_repository.dart';
import '../../screens/home/course_widget.dart';
import '../../screens/home/top_page_view.dart';
import '../../widgets/error_widget.dart';
import '../../widgets/my_cart_icon_button.dart';

class HomeTabContents extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, state) {
        if (state is Authenticated) {
          return MultiBlocProvider(
            providers: [
              BlocProvider<HomeTabBloc>(
                create: (context) => HomeTabBloc(
                  coursesRepository: CoursesRepository(),
                  categoryRepository: CategoryRepository(),
                )..add(FetchedHomeTabContents(user: state.user)),
              ),
            ],
            child: BuildHomeTabContents(),
          );
        }
        return MultiBlocProvider(
          providers: [
            BlocProvider<HomeTabBloc>(
              create: (context) => HomeTabBloc(
                coursesRepository: CoursesRepository(),
                categoryRepository: CategoryRepository(),
              )..add(FetchedHomeTabContents()),
            ),
          ],
          child: BuildHomeTabContents(),
        );
      },
    );
  }
}

class BuildHomeTabContents extends StatefulWidget {
  @override
  _BuildHomeTabContentsState createState() => _BuildHomeTabContentsState();
}

class _BuildHomeTabContentsState extends State<BuildHomeTabContents>
    with TickerProviderStateMixin {
  AnimationController _ColorAnimationController;
  AnimationController _TextAnimationController;
  Animation _colorTween, _iconColorTween;
  Animation<Offset> _transTween;
  @override
  void initState() {
    _ColorAnimationController =
        AnimationController(vsync: this, duration: Duration(seconds: 0));
    _colorTween =
        ColorTween(begin: Colors.transparent, end: CustomColors.darkBlueColor)
            .animate(_ColorAnimationController);
    _iconColorTween = ColorTween(begin: Colors.grey, end: Colors.white)
        .animate(_ColorAnimationController);

    _TextAnimationController =
        AnimationController(vsync: this, duration: Duration(seconds: 0));

    _transTween = Tween(begin: Offset(-10, 40), end: Offset(-10, 0))
        .animate(_TextAnimationController);

    super.initState();
  }

  bool _scrollListener(ScrollNotification scrollInfo) {
    if (scrollInfo.metrics.axis == Axis.vertical) {
      _ColorAnimationController.animateTo(scrollInfo.metrics.pixels / 80);

      _TextAnimationController.animateTo(
          (scrollInfo.metrics.pixels - 100) / 50);
      return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HomeTabBloc, HomeTabState>(
      builder: (context, state) {
        if (state is HomeTabContentsLoaded) {
          return Scaffold(
            body: NotificationListener(
              onNotification: _scrollListener,
              child: Stack(
                children: [
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          height: 220,
                          child: TopPageView(
                            newCourses: state.newCourses,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(15),
                          child: Column(
                            children: [
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                alignment: Alignment.center,
                                width: MediaQuery.of(context).size.width,
                                padding: EdgeInsets.all(5.0),
                                decoration: BoxDecoration(
                                  gradient: CustomColors.fabGradient,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                height: 50,
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    children: <TextSpan>[
                                      TextSpan(
                                          text:
                                              ' Learn from here and Save upto 80%',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyText1
                                              .copyWith(
                                                color: Colors.white,
                                              )),
                                      TextSpan(
                                          text: ' 5 days left!',
                                          style: Theme.of(context)
                                              .textTheme
                                              .headline5
                                              .copyWith(
                                                fontWeight: FontWeight.w600,
                                                color: Colors.white,
                                              )),
                                    ],
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 30,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Categories",
                                    style:
                                        Theme.of(context).textTheme.headline6,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      Navigator.of(context)
                                          .pushNamed('/categories');
                                    },
                                    child: Text(
                                      "SeeAll",
                                      style:
                                          Theme.of(context).textTheme.bodyText1,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              _buildCategory(state.catList),
                              SizedBox(
                                height: 20,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Popular Courses",
                                    style:
                                        Theme.of(context).textTheme.headline6,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      Navigator.of(context)
                                          .pushNamed('/all-courses');
                                    },
                                    child: Text(
                                      "SeeAll",
                                      style:
                                          Theme.of(context).textTheme.bodyText1,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.35,
                                //color: Colors.red,
                                child: _buildNewestCourses(state.courses),
                              ),
                              SizedBox(
                                height: 30,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Newest Courses",
                                    style:
                                        Theme.of(context).textTheme.headline6,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      Navigator.of(context)
                                          .pushNamed('/all-courses');
                                    },
                                    child: Text(
                                      "SeeAll",
                                      style:
                                          Theme.of(context).textTheme.bodyText1,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.30,
                                //color: Colors.red,
                                child: _buildPopularCourses(state.newCourses),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 80,
                    child: AnimatedBuilder(
                      animation: _ColorAnimationController,
                      builder: (context, child) {
                        return AppBar(
                          backgroundColor: _colorTween.value,
                          elevation: 0,
                          title: Transform.translate(
                            offset: _transTween.value,
                            child: Text(
                              "Brain Mentors",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                  ),
                            ),
                          ),
                          actions: [
                            MyCartIconButton(),
                          ],
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        }
        if (state is Failure) {
          return Scaffold(
            body: MyErrorWidget(
              errorMessage: state.errorMessage,
            ),
          );
        }
        return LoadingIndicator();
      },
    );
  }

  Widget _buildPopularCourses(List<Course> courses) {
    return ListView.builder(
      physics: BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      itemCount: courses.length,
      itemBuilder: (BuildContext context, int index) {
        return Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: AspectRatio(
            aspectRatio: MediaQuery.of(context).size.height /
                (MediaQuery.of(context).size.width * 2.2),
            child: CourseWidget(
              course: courses[index],
              maxLines: 3,
              starSize: 20,
            ),
          ),
        );
      },
    );
  }

  Widget _buildNewestCourses(List<Course> courses) {
    return ListView.builder(
      physics: BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      itemCount: courses.length,
      itemBuilder: (BuildContext context, int index) {
        return Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: AspectRatio(
            aspectRatio: MediaQuery.of(context).size.height /
                (MediaQuery.of(context).size.width * 1.8),
            child: CourseWidget(
              course: courses[index],
              maxLines: 3,
              starSize: 20,
            ),
          ),
        );
      },
    );
  }

  Widget _buildCategory(List<Category> categories) {
    return Container(
      height: 50,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.only(right: 10.0),
            child: ActionChip(
              backgroundColor: CustomColors.categoryChipColor,
              labelPadding: EdgeInsets.all(5),
              onPressed: () {
                Navigator.of(context).pushNamed('/category-courses',
                    arguments: categories[index].categoryId);
              },
              label: Text(
                "${categories[index].categoryName}",
                style: Theme.of(context)
                    .textTheme
                    .bodyText1
                    .copyWith(color: Colors.blueGrey),
              ),
            ),
          );
        },
      ),
    );
  }
}
