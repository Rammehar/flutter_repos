import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../blocs/category/category.dart';
import '../../common/common.dart';
import '../../widgets/my_cart_icon_button.dart';

class CategoriesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CategoryBloc, CategoryState>(
      builder: (context, state) {
        if (state is CategoryLoadSuccess) {
          return Scaffold(
            appBar: AppBar(
              title: Text(
                "All Categories",
                style: Theme.of(context)
                    .textTheme
                    .headline6
                    .copyWith(color: Colors.white),
              ),
              actions: [
                MyCartIconButton(),
              ],
            ),
            body: SafeArea(
              child: ListView.builder(
                itemCount: state.categories.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    //leading: Icon(Icons.access_alarm),
                    trailing: Icon(Icons.keyboard_arrow_right),
                    title: Text("${state.categories[index].categoryName}",
                        style: Theme.of(context).textTheme.headline5),
                    onTap: () {
                      Navigator.of(context).pushNamed('/category-courses',
                          arguments: state.categories[index].categoryId);
                    },
                  );
                },
              ),
            ),
          );
        }
        return LoadingIndicator();
      },
    );
  }
}
