import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/authentication/authentication.dart';
import '../../common/styles.dart';
import '../../models/course_model.dart';
import '../../utils/global_navigator_key.dart';

class TopPageView extends StatefulWidget {
  final List<Course> newCourses;
  TopPageView({this.newCourses});
  @override
  _TopPageViewState createState() => _TopPageViewState();
}

class _TopPageViewState extends State<TopPageView> {
  PageController _pageController;
  int currentIndex = 0;
  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: 0);
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
        builder: (context, state) {
      if (state is Authenticated) {
        return Stack(
          alignment: Alignment.bottomCenter,
          children: [
            PageView.builder(
              onPageChanged: (page) {
                setState(() {
                  currentIndex = page;
                });
              },
              physics: ClampingScrollPhysics(),
              controller: _pageController,
              itemCount: widget.newCourses.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    var data = {
                      "courseId": widget.newCourses[index].courseId,
                      "userId": state.user.userId,
                    };
                    GlobalNavigatorKey.navigatorKey.currentState
                        .pushNamed("/course-detail", arguments: data);
                  },
                  child: makePage(
                      imageUrl: "${widget.newCourses[index].imageUrl}",
                      title: "${widget.newCourses[index].name}",
                      reverse: false),
                );
              },
            ),
            Container(
              margin: EdgeInsets.only(bottom: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: _buildIndicator(widget.newCourses.length),
              ),
            ),
          ],
        );
      }
      return Stack(
        alignment: Alignment.bottomCenter,
        children: [
          PageView.builder(
            onPageChanged: (page) {
              setState(() {
                currentIndex = page;
              });
            },
            physics: ClampingScrollPhysics(),
            controller: _pageController,
            itemCount: widget.newCourses.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  var data = {
                    "courseId": widget.newCourses[index].courseId,
                    "userId": null,
                  };
                  GlobalNavigatorKey.navigatorKey.currentState
                      .pushNamed("/course-detail", arguments: data);
                },
                child: makePage(
                    imageUrl: "${widget.newCourses[index].imageUrl}",
                    title: "${widget.newCourses[index].name}",
                    reverse: false),
              );
            },
          ),
          Container(
            margin: EdgeInsets.only(bottom: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: _buildIndicator(widget.newCourses.length),
            ),
          ),
        ],
      );
    });
  }

  Widget makePage({imageUrl, title, reverse = false}) {
    return Stack(
      children: [
        Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.transparent,
            image: DecorationImage(
              image: NetworkImage(
                imageUrl,
              ),
              fit: BoxFit.fill,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            gradient: LinearGradient(
                begin: FractionalOffset.topCenter,
                end: FractionalOffset.bottomCenter,
                colors: [
                  Colors.grey.withOpacity(0.0),
                  CustomColors.dartGrayColor,
                ]),
          ),
        ),
        Positioned(
          bottom: 50,
          right: 20,
          left: 10,
          child: Text(
            title,
            textAlign: TextAlign.left,
            style: TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }

  List<Widget> _buildIndicator(length) {
    List<Widget> indicators = [];
    for (int i = 0; i < length; i++) {
      if (currentIndex == i) {
        indicators.add(_indicator(true));
      } else {
        indicators.add(_indicator(false));
      }
    }
    return indicators;
  }

  Widget _indicator(bool isActive) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      height: 6,
      width: isActive ? 30 : 6,
      margin: EdgeInsets.only(right: 5),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(5)),
    );
  }
}
