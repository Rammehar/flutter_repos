import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

import '../../blocs/authentication/authentication.dart';
import '../../models/course_model.dart';
import '../../utils/global_navigator_key.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CourseWidget extends StatelessWidget {
  final Course course;
  final int maxLines;
  final double starSize;
  CourseWidget({this.course, this.maxLines, this.starSize})
      : assert(course != null);
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, state) {
        if (state is Authenticated) {
          return _buildCourse(course, context, state);
        }
        return _buildCourse(course, context);
      },
    );
  }

  Widget _buildCourse(Course course, BuildContext context, [state]) {
    return GestureDetector(
      onTap: () {
        var data = {
          "courseId": course.courseId,
          "userId": state == null ? null : state.user.userId,
        };
        print('course status is ${course.purchased}');

        if (course.purchased) {
          GlobalNavigatorKey.navigatorKey.currentState
              .pushNamed('/my-course-sections', arguments: course.courseId);
        } else {
          GlobalNavigatorKey.navigatorKey.currentState
              .pushNamed('/course-detail', arguments: data);
        }
      },
      child: Container(
        // color: Colors.yellow,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.all(Radius.circular(5.0)),
              child: CachedNetworkImage(
                imageUrl: "${course.imageUrl}",
                placeholder: (context, url) => CircularProgressIndicator(),
                errorWidget: (context, url, error) => Icon(Icons.error),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            SizedBox(
              width: 300.0,
              child: AutoSizeText(
                "${course.name}",
                style: Theme.of(context).textTheme.bodyText1.copyWith(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                maxLines: maxLines,
              ),
            ),
            Row(
              children: [
                SmoothStarRating(
                  color: Colors.yellow[900],
                  rating: course.ratings,
                  isReadOnly: true,
                  size: starSize,
                  filledIconData: Icons.star,
                  halfFilledIconData: Icons.star_half,
                  defaultIconData: Icons.star_border,
                  starCount: 5,
                  allowHalfRating: true,
                  spacing: 2.0,
                  onRated: (value) {
                    print("rating value -> $value");
                    // print("rating value dd -> ${value.truncate()}");
                  },
                ),
                Text(
                  "(${course.ratings})",
                  style: Theme.of(context).textTheme.headline5.copyWith(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                ),
              ],
            ),
            Text(
              "\u{20B9} ${course.price}",
              style: Theme.of(context).textTheme.headline6.copyWith(
                    fontSize: 15,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
