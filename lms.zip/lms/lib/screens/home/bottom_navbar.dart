import '../../models/bottom_navigation_tab.dart';
import 'package:flutter/material.dart';

class BottomNavBar extends StatelessWidget {
  final Function(BottomNavigationTab) onTabSelected;
  final BottomNavigationTab activeTab;
  BottomNavBar({this.onTabSelected, this.activeTab});

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      onTap: (index) => onTabSelected(BottomNavigationTab.values[index]),
      currentIndex: BottomNavigationTab.values.indexOf(activeTab),
      unselectedItemColor: Colors.white70,
      unselectedLabelStyle: TextStyle(
        fontFamily: "Montserrat-Bold",
      ),
      selectedLabelStyle: TextStyle(
        fontFamily: "Montserrat-Bold",
      ),
      selectedItemColor: Colors.white,
      backgroundColor: Color(0xFF17172E),
      unselectedFontSize: 10,
      selectedFontSize: 10,
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          title: Text('Courses'),
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.search),
          title: Text('Search'),
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.play_circle_outline),
          title: Text('My Courses'),
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.account_circle),
          title: Text('Account'),
        ),
      ],
    );
  }
}
