import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/bottom_tab/bottom_tab.dart';
import '../../models/bottom_navigation_tab.dart';
import '../../models/user_model.dart';
import '../../utils/tab_navigator.dart';
import 'bottom_navbar.dart';

class HomeScreen extends StatelessWidget {
  final User user;
  HomeScreen({this.user});
  @override
  Widget build(BuildContext context) {
    Future<bool> _onBackPressed() async {
      return showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Message!"),
          content: Text('Do You really want to Exit?'),
          actions: [
            FlatButton(
              child: Text('No'),
              onPressed: () {
                Navigator.of(context).pop(false);
              },
            ),
            FlatButton(
              child: Text('Yes'),
              onPressed: () {
                Navigator.of(context).pop(true);
              },
            ),
          ],
        ),
      );
    }

    return BlocBuilder<BottomTabBloc, BottomNavigationTab>(
      builder: (context, activeTab) {
        return WillPopScope(
          onWillPop: () async {
            bool result =
                !await navigatorKeys[activeTab].currentState.maybePop();

            if (result) {
              if (activeTab != BottomNavigationTab.courses) {
                BlocProvider.of<BottomTabBloc>(context)
                    .add(UpdateBottomTabEvent(BottomNavigationTab.courses));
                return false;
              }
              return result;
            }
            return result;
          },
          child: Scaffold(
            body: TabNavigator(
              tabItem: activeTab,
              navigatorKey: navigatorKeys[activeTab],
            ),
            bottomNavigationBar: BottomNavBar(
              activeTab: activeTab,
              onTabSelected: (tab) => BlocProvider.of<BottomTabBloc>(context)
                  .add(UpdateBottomTabEvent(tab)),
            ),
          ),
        );
      },
    );
  }

  Widget _buildOffstageNavigator(BottomNavigationTab tabItem, activeTab) {
    return Offstage(
      offstage: activeTab != tabItem,
      child: TabNavigator(
        tabItem: tabItem,
      ),
    );
  }
}
