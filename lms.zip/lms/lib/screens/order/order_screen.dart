import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/order/order.dart';
import '../../common/inkwell_button.dart';
import '../../common/styles.dart';
import '../../models/order_model.dart';
import '../../utils/global_navigator_key.dart';

class OrderScreen extends StatelessWidget {
  final Order order;
  OrderScreen({@required this.order}) : assert(order != null);
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<OrderBloc, OrderState>(
      listener: (context, state) {
        if (state is OrderSavedSuccess) {
          GlobalNavigatorKey.navigatorKey.currentState
              .pushNamed('/payment', arguments: state.order);
        }
      },
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            title: Text(
              "CheckOut",
              style: Theme.of(context).textTheme.headline6.copyWith(
                    color: Colors.white,
                  ),
            ),
          ),
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Card(
                    child: Container(
                      padding: EdgeInsets.all(15),
                      child: Column(
                        children: [
                          Text(
                            "Order Summary",
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Table(
                            columnWidths: {
                              0: FlexColumnWidth(1.0),
                              1: IntrinsicColumnWidth()
                            },
                            children: [
                              TableRow(
                                  decoration: BoxDecoration(
                                      border: Border(bottom: BorderSide())),
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0),
                                      child: Text(
                                        "CourseName",
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline5,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0),
                                      child: Text(
                                        "Price",
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline5,
                                      ),
                                    ),
                                  ]),
                              for (var course in order.courses)
                                TableRow(children: [
                                  Padding(
                                      padding:
                                          EdgeInsets.symmetric(vertical: 8.0),
                                      child: Text(
                                        '${course.name}',
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyText1,
                                      )),
                                  Padding(
                                      padding:
                                          EdgeInsets.symmetric(vertical: 8.0),
                                      child: Text(
                                        "${course.price}",
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyText1,
                                      )),
                                ]),
                              TableRow(
                                  decoration: BoxDecoration(
                                      border: Border(top: BorderSide())),
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0),
                                      child: Text(
                                        "Total",
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyText1,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0),
                                      child: Text(
                                        "${order.totalAmount}",
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyText1,
                                      ),
                                    ),
                                  ]),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 20.0, horizontal: 5),
                    child: InkWellButton(
                      height: 40,
                      text: "Complete Payment",
                      color: CustomColors.darkBlueColor,
                      onTap: () {
                        BlocProvider.of<OrderBloc>(context)
                            .add(SaveOrder(order: order));
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
