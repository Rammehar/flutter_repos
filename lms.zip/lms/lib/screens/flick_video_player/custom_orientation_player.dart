import 'dart:ui';

import 'package:flick_video_player/flick_video_player.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';

import '../../models/course_model.dart';
import '../../models/item_model.dart';
import '../../models/user_model.dart';
import '../../widgets/favorite.dart';
import '../../widgets/feedback.dart';
import 'controls.dart';
import 'data_manager.dart';

class CustomOrientationPlayer extends StatefulWidget {
  CustomOrientationPlayer({Key key, this.course, this.user}) : super(key: key);
  final Course course;
  final User user;

  @override
  _CustomOrientationPlayerState createState() =>
      _CustomOrientationPlayerState();
}

int playingIndex = 0;

class _CustomOrientationPlayerState extends State<CustomOrientationPlayer> {
  FlickManager flickManager;
  DataManager dataManager;
  List<String> urls = [];
  List<Item> _items = [];

  @override
  void initState() {
    super.initState();
    _loadSectionsAndContents();
    playingIndex = 0;
    flickManager = FlickManager(
        videoPlayerController: VideoPlayerController.network(urls[0]),
        onVideoEnd: () {
          dataManager.skipToNextVideo(Duration(seconds: 5));
        });
    dataManager = DataManager(flickManager: flickManager, urls: urls);
    dataManager.addListener(_playingIndex);
  }

  _loadSectionsAndContents() {
    for (var section in widget.course.sections) {
      _items.add(Item(sectionName: section.sectionName));
      for (var content in section.contents) {
        var _url = "${content.mpdUrl}?tokenid=${widget.user.tokenId}";
         print(_url);
        _items.add(Item(content: content, mpdUrl: _url));
        urls.add(_url);
      }
    }
  }

  _playingIndex() {
    playingIndex = dataManager.currentPlaying;
    setState(() {});
  }

  @override
  void dispose() {
    flickManager.dispose();
    dataManager.removeListener(_playingIndex);
    super.dispose();
  }

  skipToVideo(String url) {
    flickManager.handleChangeVideo(VideoPlayerController.network(url));
  }

  @override
  Widget build(BuildContext context) {
    return VisibilityDetector(
      key: ObjectKey(flickManager),
      onVisibilityChanged: (visibility) {
        if (visibility.visibleFraction == 0 && this.mounted) {
          flickManager.flickControlManager.autoPause();
        } else if (visibility.visibleFraction == 1) {
          flickManager.flickControlManager.autoResume();
        }
      },
      child: Column(
        children: <Widget>[
          //video player
          AspectRatio(
            aspectRatio: 16 / 9,
            child: FlickVideoPlayer(
              flickManager: flickManager,
              preferredDeviceOrientationFullscreen: [
                DeviceOrientation.portraitUp,
                DeviceOrientation.landscapeLeft,
                DeviceOrientation.landscapeRight,
              ],
              flickVideoWithControls: FlickVideoWithControls(
                controls: CustomOrientationControls(
                  dataManager: dataManager,
                  user: widget.user,
                ),
              ),
              flickVideoWithControlsFullscreen: FlickVideoWithControls(
                videoFit: BoxFit.fitWidth,
                controls: CustomOrientationControls(
                  dataManager: dataManager,
                  user: widget.user,
                ),
              ),
            ),
          ),
          Expanded(
            child: DefaultTabController(
              length: 2,
              child: NestedScrollView(
                headerSliverBuilder: (context, innerBoxIsScrolled) {
                  return [
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.all(18.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              '${widget.course.name}',
                              style: Theme.of(context).textTheme.headline6,
                              maxLines: 1,
                            ),
                            Text(
                              'Author: ${widget.course.author}',
                              style: Theme.of(context).textTheme.bodyText1,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ];
                },
                body: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            width: 1,
                            color: Colors.grey[200],
                          ),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: 200,
                            child: TabBar(
                              indicatorColor: Colors.transparent,
                              //isScrollable: true,
                              labelColor: Colors.blue[900],
                              unselectedLabelColor: Colors.grey,
                              labelStyle: Theme.of(context)
                                  .textTheme
                                  .headline5
                                  .copyWith(
                                    fontWeight: FontWeight.bold,
                                  ),
                              tabs: [
                                Tab(
                                  text: "Lectures",
                                ),
                                Tab(
                                  text: "More",
                                )
                              ],
                            ),
                          ),
                          Expanded(
                            child: FeedBackWidget(
                                course: widget.course, user: widget.user),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: TabBarView(
                        children: [
                          SectionContents(
                            user: widget.user,
                            dataManager: dataManager,
                            items: _items,
                            skipVideo: skipToVideo,
                          ),
                          MoreInfo(
                            widget.course,
                            widget.user,
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}

class SectionContents extends StatelessWidget {
  final User user;
  final DataManager dataManager;
  final List<Item> items;
  final Function(String url) skipVideo;
  SectionContents({this.user, this.dataManager, this.items, this.skipVideo});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18.0),
      child: ListView.builder(
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        itemCount: items.length,
        itemBuilder: (context, index) {
          if (items[index].content == null) {
            return Text(
              "Section:  ${items[index].sectionName}",
              maxLines: 1,
              style:
                  Theme.of(context).textTheme.headline5.copyWith(fontSize: 12),
            );
          }
          var isPlayingIndex =
              (items[index].content.serialNo - 1) == playingIndex;

          return Padding(
            padding: EdgeInsets.symmetric(
              vertical: 6,
            ),
            child: ListTile(
              contentPadding: EdgeInsets.all(0),
              onTap: () => dataManager
                  .playSelectedVideo(items[index].content.serialNo - 1),
//              onTap: () {
//                skipVideo(items[index].mpdUrl);
//              },
              dense: true,
              title: Row(
                children: [
                  Text(
                    "${items[index].content.serialNo}",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        isPlayingIndex
                            ? Text(
                                "${items[index].content.videoName}",
                                style: TextStyle(
                                  color: Colors.blue,
                                  fontWeight: FontWeight.w600,
                                ),
                              )
                            : Text(
                                "${items[index].content.videoName}",
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                        Text(
                          "Video - ${items[index].content.duration} mins",
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey[600],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class MoreInfo extends StatelessWidget {
  final Course course;
  final User user;
  MoreInfo(this.course, this.user);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 18),
      child: SingleChildScrollView(
        child: Column(
          children: [
            ListTile(
              leading: Icon(Icons.more_horiz),
              title: Text(
                "About This Course",
                style: Theme.of(context).textTheme.headline5,
              ),
            ),
            FavoriteWidget(
              course: course,
              user: user,
            ),
            ListTile(
              leading: Icon(Icons.notifications_none),
              title: Text(
                "Announcements",
                style: Theme.of(context).textTheme.headline5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
