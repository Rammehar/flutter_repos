import 'dart:async';
import 'package:flick_video_player/flick_video_player.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class DataManager extends ChangeNotifier {
  DataManager({this.flickManager, this.urls});

  int currentPlaying = 0;
  final FlickManager flickManager;
  final List<String> urls;

  Timer videoChangeTimer;

  String getNextVideo() {
    currentPlaying++;
    notifyListeners();
    return urls[currentPlaying];
  }

  bool hasNextVideo() {
    return currentPlaying != urls.length - 1;
  }

  bool hasPreviousVideo() {
    return currentPlaying != 0;
  }

  skipToNextVideo([Duration duration]) {
    if (hasNextVideo()) {
      flickManager.handleChangeVideo(
          VideoPlayerController.network(urls[currentPlaying + 1]),
          videoChangeDuration: duration);
      currentPlaying++;
      notifyListeners();
    }
  }

  skipToPreviousVideo() {
    if (hasPreviousVideo()) {
      currentPlaying--;
      notifyListeners();
      flickManager.handleChangeVideo(
          VideoPlayerController.network(urls[currentPlaying]));
    }
  }

  playSelectedVideo(int index) {
    currentPlaying = index;
    notifyListeners();
    flickManager
        .handleChangeVideo(VideoPlayerController.network(urls[currentPlaying]));
  }

  cancelVideoAutoPlayTimer({bool playNext}) {
    if (playNext != true) {
      currentPlaying--;
      notifyListeners();
    }
    flickManager.flickVideoManager.cancelVideoAutoPlayTimer(playNext: playNext);
  }
}
