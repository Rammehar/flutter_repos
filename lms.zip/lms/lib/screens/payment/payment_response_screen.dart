import 'package:flutter/material.dart';

class PaymentResponseScreen extends StatelessWidget {
  final Map<String, dynamic> responseData;
  PaymentResponseScreen({this.responseData});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text("I am payment respnose"),
      ),
    );
  }
}
