import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../blocs/authentication/authentication.dart';
import '../../blocs/cart/cart.dart';
import '../../models/order_model.dart';
import '../../utils/global_navigator_key.dart';

enum PaymentResponse {
  Loading,
  Successful,
  Pending,
  Failed,
  ChecksumFailed,
}

class PaymentScreen extends StatefulWidget {
  final Order order;
  PaymentScreen(this.order) : assert(order != null);

  @override
  _PaymentScreenState createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  WebViewController _webController;
  final paytmUrl = "http://13.233.27.240:5000/paytm/payment";
  PaymentResponse _paymentResponse = PaymentResponse.Loading;
  bool _loadingPayment = true;

  String _loadHTML() {
    return "<html> <body onload='document.f.submit();'> <form id='f' name='f' method='post' action='$paytmUrl'><input type='hidden' name='orderID' value='${widget.order.orderId}'/>" +
        "<input  type='hidden' name='custID' value='${widget.order.userId}' />" +
        "<input  type='hidden' name='amount' value='${widget.order.totalAmount}' />" +
        "<input type='hidden' name='custEmail' value='${widget.order.user.userName}' />" +
        "<input type='hidden' name='custPhone' value='${widget.order.user.phoneNo}' />" +
        "</form> </body> </html>";
  }

  void getData() {
    _webController.evaluateJavascript("document.body.innerText").then((data) {
      var decodedJSON = jsonDecode(data);
      Map<String, dynamic> responseJSON = jsonDecode(decodedJSON);
      final checksumResult = responseJSON["status"];
      final paytmResponse = responseJSON["data"];

      if (paytmResponse["STATUS"] == "TXN_SUCCESS") {
        if (checksumResult == 0) {
          _paymentResponse = PaymentResponse.Successful;
        } else {
          _paymentResponse = PaymentResponse.ChecksumFailed;
        }
      } else if (paytmResponse["STATUS"] == "TXN_FAILURE") {
        _paymentResponse = PaymentResponse.Failed;
      }
      this.setState(() {});
    });
  }

  @override
  void dispose() {
    _webController = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          body: Stack(
        children: <Widget>[
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: WebView(
              debuggingEnabled: false,
              javascriptMode: JavascriptMode.unrestricted,
              onWebViewCreated: (controller) {
                _webController = controller;
                _webController.loadUrl(
                    Uri.dataFromString(_loadHTML(), mimeType: 'text/html')
                        .toString());
              },
              onPageFinished: (page) {
                if (page.contains("/process")) {
                  if (_loadingPayment) {
                    this.setState(() {
                      _loadingPayment = false;
                    });
                  }
                }
                if (page.contains("/paymentReceipt")) {
                  getData();
                }
              },
            ),
          ),
          (_loadingPayment)
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : Center(),
          (_paymentResponse != PaymentResponse.Loading)
              ? Center(child: getResponseScreen())
              : Center()
        ],
      )),
    );
  }

  Widget getResponseScreen() {
    switch (_paymentResponse) {
      case PaymentResponse.Successful:
        return TransactionMessage(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 50,
                width: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(50),
                ),
                child: Icon(
                  Icons.done,
                  size: 30,
                  color: Colors.white,
                ),
              ),
              Text(
                "Payment Successful",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
              ),
              Text(
                "Its our pleasure to offer you our Course!",
                style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        );
      case PaymentResponse.ChecksumFailed:
        return TransactionMessage(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 50,
                width: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(50),
                ),
                child: Icon(
                  Icons.error_outline,
                  size: 30,
                  color: Colors.white,
                ),
              ),
              Text(
                "Contact Support!",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
              ),
              Text(
                "Not Sure payment Received or Not!",
                style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        );
      case PaymentResponse.Failed:
        return TransactionMessage(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 50,
                width: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.red,
                  borderRadius: BorderRadius.circular(50),
                ),
                child: Icon(
                  Icons.error_outline,
                  size: 30,
                  color: Colors.white,
                ),
              ),
              Text(
                "Payment Failed",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
              ),
              Text(
                "It seems we have not received money!",
                style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        );
    }
    return TransactionMessage(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 50,
            width: 50,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.green,
              borderRadius: BorderRadius.circular(50),
            ),
            child: Icon(
              Icons.done,
              size: 30,
              color: Colors.white,
            ),
          ),
          Text(
            "Payment Successful",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
          ),
          Text(
            "Its our pleasure to offer you our Course!",
            style: TextStyle(
                fontSize: 14, color: Colors.grey, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

class TransactionMessage extends StatelessWidget {
  final Widget child;
  TransactionMessage({this.child});
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, state) {
        if (state is Authenticated) {
          BlocProvider.of<CartBloc>(context).add(LoadCart(user: state.user));
          Timer(
            Duration(seconds: 3),
            () => GlobalNavigatorKey.navigatorKey.currentState
                .pushNamedAndRemoveUntil('/', ModalRoute.withName('/')),
          );
          return Scaffold(
            body: Center(
              child: child,
            ),
          );
        }
        return Container();
      },
    );
  }
}
