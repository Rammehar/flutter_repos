import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

import '../../blocs/cart/cart.dart';
import '../../common/common.dart';
import '../../common/inkwell_button.dart';
import '../../common/platform_alert_dialog.dart';
import '../../common/styles.dart';
import '../../models/cart_model.dart';
import '../../models/course_model.dart';
import '../../models/order_model.dart';
import '../../models/user_model.dart';
import '../../utils/global_navigator_key.dart';

class CartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<CartBloc, CartState>(
      listener: (context, state) {
        if (state is OrderLoadedSuccess) {
          GlobalNavigatorKey.navigatorKey.currentState
              .pushNamed('/payment', arguments: state.order);
        }
      },
      builder: (BuildContext context, state) {
        if (state is CartLoadedSuccess) {
          return Scaffold(
            extendBody: true,
            appBar: AppBar(
              title: Text(
                "Your Cart",
                style: Theme.of(context).textTheme.headline6.copyWith(
                      color: Colors.white,
                    ),
              ),
            ),
            body: _buildCartItemList(state.cart.courses, state.user),
            bottomNavigationBar:
                _buildCheckOutButton(context, state.cart, state.user),
          );
        }
        return LoadingIndicator();
      },
    );
  }

  Widget _buildCheckOutButton(BuildContext context, Cart cart, User user) {
    return cart.courses.length > 0
        ? Container(
            height: 50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    child: Column(
                      children: [
                        Text(
                          'Total Items',
                          style: Theme.of(context).textTheme.bodyText1,
                        ),
                        Text(
                          '${cart.totalCourses}',
                          style: Theme.of(context).textTheme.bodyText1,
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: InkWellButton(
                      height: 50,
                      text: "CheckOut",
                      color: CustomColors.darkBlueColor,
                      onTap: () {
                        BlocProvider.of<CartBloc>(context).add(
                          CheckoutButtonPressed(
                            order: Order(
                              userId: user.userId,
                              courses: cart.courses,
                              totalAmount: cart.totalCost,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    child: Column(
                      children: [
                        Text(
                          'Total Cost',
                          style: Theme.of(context).textTheme.bodyText1,
                        ),
                        Text(
                          '\u20B9 ${cart.totalCost}',
                          style: Theme.of(context).textTheme.bodyText1,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          )
        : Container();
  }

  Widget _buildCartItemList(List<Course> courses, user) {
    return courses.length > 0
        ? ListView.builder(
            itemCount: courses.length,
            itemBuilder: (BuildContext context, index) {
              return Padding(
                padding: const EdgeInsets.all(12.0),
                child: ItemWidget(courses[index], user),
              );
            },
          )
        : Center(
            child: Text(
              "Your Cart is Empty!",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          );
  }
}

class ItemWidget extends StatelessWidget {
  final Course course;
  final User user;
  ItemWidget(this.course, this.user) : assert(course != null);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GestureDetector(
          onTap: () {
            var data = {
              "courseId": course.courseId,
              "userId": user.userId,
            };
            GlobalNavigatorKey.navigatorKey.currentState
                .pushNamed('/course-detail', arguments: data);
          },
          child: Row(
            children: [
              Container(
                alignment: Alignment.topCenter,
                height: 80,
                width: 90,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: NetworkImage("${course.imageUrl}"),
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "${course.name}",
                      style: Theme.of(context).textTheme.bodyText1,
                    ),
                    Text(
                      "${course.author}",
                      style: Theme.of(context)
                          .textTheme
                          .bodyText1
                          .copyWith(color: Colors.black45),
                    ),
                    SmoothStarRating(
                      color: Colors.yellow[900],
                      rating: course.ratings,
                      isReadOnly: true,
                      size: 20,
                      filledIconData: Icons.star,
                      halfFilledIconData: Icons.star_half,
                      defaultIconData: Icons.star_border,
                      starCount: 5,
                      allowHalfRating: true,
                      spacing: 2.0,
                      onRated: (value) {
                        print("rating value -> $value");
                        // print("rating value dd -> ${value.truncate()}");
                      },
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "\u{20B9} ${course.price}",
                          style: Theme.of(context).textTheme.bodyText1,
                        ),
                        GestureDetector(
                          child: Text(
                            "Remove",
                            style: Theme.of(context)
                                .textTheme
                                .bodyText1
                                .copyWith(color: Colors.blue),
                          ),
                          onTap: () {
                            _confirmRemoveItem(context);
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Divider(),
      ],
    );
  }

  Future<void> _confirmRemoveItem(BuildContext context) async {
    final didRequestRemove = await PlatformAlertDialog(
      title: 'Remove Course From Cart',
      content: 'Are you sure that you want to Remove?',
      cancelActionText: 'Cancel',
      defaultActionText: 'Yes',
    ).show(context);
    if (didRequestRemove == true) {
      _removeItem(context);
    }
  }

  _removeItem(BuildContext context) {
    BlocProvider.of<CartBloc>(context)
        .add(RemoveFromCart(course.courseId, user));
  }
}
