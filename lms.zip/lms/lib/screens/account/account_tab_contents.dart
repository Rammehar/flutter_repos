import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/authentication/authentication.dart';
import '../../common/platform_alert_dialog.dart';
import '../../utils/global_navigator_key.dart';
import '../../widgets/my_cart_icon_button.dart';

class AccountTabContents extends StatelessWidget {
  Future<void> _signOut(BuildContext context, user) async {
    try {
      BlocProvider.of<AuthenticationBloc>(context).add(LoggedOut(
        user: user,
      ));
    } catch (e) {
      print(e.toString());
    }
  }

  Future<void> _confirmSignOut(BuildContext context, user) async {
    final didRequestSignOut = await PlatformAlertDialog(
      title: 'Logout',
      content: 'Are you sure that you want to logout?',
      cancelActionText: 'Cancel',
      defaultActionText: 'Logout',
    ).show(context);
    if (didRequestSignOut == true) {
      _signOut(context, user);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Account",
          style: Theme.of(context)
              .textTheme
              .headline6
              .copyWith(color: Colors.white),
        ),
        actions: [
          MyCartIconButton(),
        ],
      ),
      body: BlocBuilder<AuthenticationBloc, AuthenticationState>(
        builder: (context, state) {
          if (state is Authenticated) {
            return Center(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(
                      height: 10,
                    ),
                    CircleAvatar(
                      maxRadius: 50,
                      backgroundImage: NetworkImage('${state.user.imageUrl}'),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      '${state.user.userName}.',
                      style: Theme.of(context).textTheme.headline6,
                    ),
                    Text(
                      '${state.user.emailId}.',
                      style: Theme.of(context).textTheme.headline5,
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    Text(
                      "Support",
                      style: Theme.of(context).textTheme.headline6,
                    ),
                    Divider(),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 18),
                      child: Column(
                        children: [
                          ListTile(
                            trailing: Icon(Icons.keyboard_arrow_right),
                            title: Text(
                              "About LMS",
                              style: Theme.of(context).textTheme.headline5,
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "Term of Use",
                              style: Theme.of(context).textTheme.headline5,
                            ),
                            trailing: Icon(Icons.keyboard_arrow_right),
                          ),
                          ListTile(
                            title: Text(
                              "Private Policy",
                              style: Theme.of(context).textTheme.headline5,
                            ),
                            trailing: Icon(Icons.keyboard_arrow_right),
                          ),
                          ListTile(
                            title: Text(
                              "Frequently Asked Questions",
                              style: Theme.of(context).textTheme.headline5,
                            ),
                            trailing: Icon(Icons.keyboard_arrow_right),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    InkWell(
                      child: Text(
                        'Logout',
                        style: Theme.of(context).textTheme.bodyText1,
                      ),
                      onTap: () => _confirmSignOut(context, state.user),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                  ],
                ),
              ),
            );
          }
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Support",
                  style: Theme.of(context).textTheme.headline6,
                ),
                Divider(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 18),
                  child: Column(
                    children: [
                      ListTile(
                        trailing: Icon(Icons.keyboard_arrow_right),
                        title: Text(
                          "About LMS",
                          style: Theme.of(context).textTheme.headline5,
                        ),
                      ),
                      ListTile(
                        title: Text(
                          "Term of Use",
                          style: Theme.of(context).textTheme.headline5,
                        ),
                        trailing: Icon(Icons.keyboard_arrow_right),
                      ),
                      ListTile(
                        title: Text(
                          "Private Policy",
                          style: Theme.of(context).textTheme.headline5,
                        ),
                        trailing: Icon(Icons.keyboard_arrow_right),
                      ),
                      ListTile(
                        title: Text(
                          "Frequently Asked Questions",
                          style: Theme.of(context).textTheme.headline5,
                        ),
                        trailing: Icon(Icons.keyboard_arrow_right),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                InkWell(
                  child: Text(
                    'Sign In',
                    style: Theme.of(context).textTheme.bodyText1,
                  ),
                  onTap: () {
                    GlobalNavigatorKey.navigatorKey.currentState
                        .pushReplacementNamed('/signin');
                  },
                ),
                SizedBox(
                  height: 40,
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
