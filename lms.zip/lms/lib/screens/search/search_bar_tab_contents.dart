import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/authentication/authentication.dart';
import '../../blocs/category/category.dart';
import '../../blocs/course/courses.dart';
import '../../blocs/top_search_key/top_search_key_bloc.dart';
import '../../blocs/top_search_key/top_search_key_state.dart';
import '../../common/styles.dart';
import '../../models/course_model.dart';
import '../../repositories/courses_repository.dart';
import '../../screens/home/courses_list.dart';

class SearchBarTabContents extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<CoursesBloc>(
          create: (context) =>
              CoursesBloc(coursesRepository: CoursesRepository()),
        ),
      ],
      child: SearchBarTab(),
    );
  }
}

class SearchBarTab extends StatelessWidget {
  Future<void> _showSearch(BuildContext context, [query]) async {
    await showSearch<Course>(
        query: query,
        context: context,
        delegate: SearchCourses(BlocProvider.of<CoursesBloc>(context)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Search Courses",
          style: Theme.of(context)
              .textTheme
              .headline6
              .copyWith(color: Colors.white),
        ),
        actions: [
          IconButton(
              icon: Icon(
                Icons.search,
                color: Colors.white,
                size: 30,
              ),
              onPressed: () {
                _showSearch(context);
              }),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 18.0, vertical: 18.0),
                child: Text(
                  "Top Searches",
                  style: Theme.of(context).textTheme.headline6,
                ),
              ),
              BuildTopSearchesKeywords(
                showSearch: _showSearch,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 18.0, vertical: 18.0),
                child: Text(
                  "Browse Categories",
                  style: Theme.of(context).textTheme.headline6,
                ),
              ),
              BuildAllCategories(),
            ],
          ),
        ),
      ),
    );
  }
}

class BuildTopSearchesKeywords extends StatelessWidget {
  final Function showSearch;
  BuildTopSearchesKeywords({this.showSearch});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TopSearchKeyBloc, TopSearchKeyState>(
      builder: (context, state) {
        if (state is TopSearchKeyFetchedState) {
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Wrap(
              runSpacing: 10,
              spacing: 10,
              children: state.searchKeys
                  .map((item) => ActionChip(
                        backgroundColor: CustomColors.categoryChipColor,
                        onPressed: () {
                          showSearch(context, item);
                        },
                        label: Text(
                          "$item",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1
                              .copyWith(color: Colors.blueGrey),
                        ),
                      ))
                  .toList(),
            ),
          );
        }
        return Container();
      },
    );
  }
}

class BuildAllCategories extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CategoryBloc, CategoryState>(
      builder: (context, state) {
        if (state is CategoryLoadSuccess) {
          return ListView.builder(
            physics: BouncingScrollPhysics(),
            shrinkWrap: true,
            itemCount: state.categories.length,
            itemBuilder: (context, index) {
              return ListTile(
                trailing: Icon(Icons.keyboard_arrow_right),
                title: Text("${state.categories[index].categoryName}",
                    style: Theme.of(context).textTheme.headline5),
                onTap: () {
                  Navigator.of(context).pushNamed('/category-courses',
                      arguments: state.categories[index].categoryId);
                },
              );
            },
          );
        }
        return Container();
      },
    );
  }
}

class SearchCourses extends SearchDelegate<Course> {
  final Bloc<CoursesEvent, CoursesState> coursesBloc;
  SearchCourses(this.coursesBloc) : super();

  @override
  String get searchFieldLabel => "Enter Search Text..";
  @override
  TextStyle get searchFieldStyle => TextStyle(color: Colors.white);

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return Container();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    String q = query.trim();

    if (q.isNotEmpty) {
      return BlocBuilder<AuthenticationBloc, AuthenticationState>(
        builder: (context, state) {
          if (state is Authenticated) {
            coursesBloc.add(CoursesSearchEvent(query: query, user: state.user));
            return BlocBuilder(
              cubit: coursesBloc,
              builder: (BuildContext context, state) {
                if (state is CoursesLoadInProgress) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }
                if (state is CoursesLoadSuccess) {
                  if (state.courses.isNotEmpty) {
                    return CoursesList(
                      courses: state.courses,
                    );
                  }
                  return Center(
                    child: Text(
                      "No Result Found!",
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  );
                }
                if (state is CoursesLoadFailure) {
                  return Center(
                    child: Text(
                      "${state.errorMessage}",
                      style: Theme.of(context).textTheme.headline5,
                    ),
                  );
                }
                return Container(
                  child: Center(child: Text('Error in Fetching!')),
                );
              },
            );
          }
          coursesBloc.add(CoursesSearchEvent(query: query));
          return BlocBuilder(
            cubit: coursesBloc,
            builder: (BuildContext context, state) {
              if (state is CoursesLoadInProgress) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
              if (state is CoursesLoadSuccess) {
                if (state.courses.isNotEmpty) {
                  return CoursesList(
                    courses: state.courses,
                  );
                }
                return Center(
                  child: Text(
                    "No Result Found!",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                );
              }
              if (state is CoursesLoadFailure) {
                return Center(
                  child: Text(
                    "${state.errorMessage}",
                    style: Theme.of(context).textTheme.headline5,
                  ),
                );
              }
              return Container(
                child: Center(child: Text('Error in Fetching!')),
              );
            },
          );
        },
      );
    }
    return Container();
  }
}
