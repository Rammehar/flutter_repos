import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/authentication/authentication.dart';
import '../../blocs/my_courses/my_courses_bloc.dart';
import '../../blocs/my_courses/my_courses_event.dart';
import '../../blocs/my_courses/my_courses_state.dart';
import '../../common/loading_indicator.dart';
import '../../repositories/mycourses_repository.dart';
import '../../utils/global_navigator_key.dart';
import '../../widgets/error_widget.dart';
import '../../widgets/my_cart_icon_button.dart';

class MyCoursesTabContents extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, state) {
        if (state is Authenticated) {
          return MultiBlocProvider(
            providers: [
              BlocProvider<MyCoursesBloc>(
                create: (context) => MyCoursesBloc(
                    myCoursesRepository: MyCoursesRepository(),
                    user: state.user)
                  ..add(MyCoursesFetched()),
              ),
            ],
            child: MyCoursesList(),
          );
        }
        return Scaffold(
          appBar: AppBar(
            title: Text(
              "My Courses",
              style: Theme.of(context)
                  .textTheme
                  .headline6
                  .copyWith(color: Colors.white),
            ),
            actions: [
              MyCartIconButton(),
            ],
          ),
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Learn Something New!",
                  style: Theme.of(context).textTheme.headline6,
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  "Your courses goes here.",
                  style: Theme.of(context).textTheme.headline5,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class MyCoursesList extends StatefulWidget {
  @override
  _MyCoursesListState createState() => _MyCoursesListState();
}

class _MyCoursesListState extends State<MyCoursesList> {
  Completer<void> _refreshCompleter;
  @override
  void initState() {
    super.initState();
    _refreshCompleter = Completer<void>();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "My Courses",
          style: Theme.of(context)
              .textTheme
              .headline6
              .copyWith(color: Colors.white),
        ),
        actions: [
          MyCartIconButton(),
        ],
      ),
      body: BlocConsumer<MyCoursesBloc, MyCoursesState>(
        listener: (context, state) {
          if (state is MyCoursesLoadSuccess) {
            _refreshCompleter?.complete();
            _refreshCompleter = Completer();
          }
        },
        builder: (context, state) {
          if (state is MyCoursesLoadSuccess) {
            return RefreshIndicator(
              onRefresh: () {
                BlocProvider.of<MyCoursesBloc>(context).add(
                  MyCourseRefreshRequested(),
                );
                return _refreshCompleter.future;
              },
              child: ListView.builder(
                itemCount: state.myCourses.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: Container(
                      height: 45,
                      width: 60,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: NetworkImage(
                              "${state.myCourses[index].imageUrl}"),
                          fit: BoxFit.fill,
                        ),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    title: Text(
                      '${state.myCourses[index].name}',
                      style: Theme.of(context).textTheme.headline5,
                      maxLines: 1,
                    ),
                    // subtitle: Text('${state.myCourses[index].description}'),
                    subtitle: RichText(
                      overflow: TextOverflow.ellipsis,
                      strutStyle: StrutStyle(fontSize: 12.0),
                      text: TextSpan(
                          style: TextStyle(color: Colors.blueGrey),
                          text: '${state.myCourses[index].author}'),
                    ),
                    trailing: Icon(Icons.chevron_right),
                    onTap: () {
                      GlobalNavigatorKey.navigatorKey.currentState.pushNamed(
                          '/my-course-sections',
                          arguments: state.myCourses[index].courseId);
                    },
                  );
                },
              ),
            );
          }
          if (state is MyCoursesLoadFailure) {
            return Scaffold(
              body: MyErrorWidget(
                errorMessage: state.errorMessage,
              ),
            );
          }
          return LoadingIndicator();
        },
      ),
    );
  }
}
