import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import './login_form.dart';
import '../../animation/fade_animation.dart';
import '../../common/styles.dart';

class LoginScreen extends StatelessWidget {
  final String messageOfRegistration;
  LoginScreen([this.messageOfRegistration]);

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: true,
      body: SingleChildScrollView(
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(FocusNode());
          },
          child: Container(
            padding: EdgeInsets.symmetric(
              horizontal: 30,
            ),
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("assets/images/login_bg.jpg"))),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                messageOfRegistration != null
                    ? FadeAnimation(
                        1.4,
                        Text(
                          "$messageOfRegistration",
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ))
                    : Container(),
                FadeAnimation(1.3, LoginForm()),
                Text(
                  "By proceeding you are agree to our Terms of Use and Privacy Police.",
                  style: Theme.of(context).textTheme.bodyText1.copyWith(
                        color: CustomColors.whiteColor,
                        fontSize: 9.0,
                      ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
