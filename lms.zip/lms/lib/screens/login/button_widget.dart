import 'package:flutter/material.dart';
class ButtonWidget extends StatelessWidget {

  final String text;
  final Color splashColor;
  final Color highlightColor;
  final Color fillColor;
  final Color textColor;
  final Function onPressed;
  ButtonWidget({
    @required this.text,
    @required this.splashColor,
    @required this.highlightColor,
    @required this.fillColor,
    @required this.textColor,
    @required this.onPressed,
});
  @override
  Widget build(BuildContext context) {
    return RaisedButton(
      highlightElevation: 0.0,
      splashColor: splashColor,
      highlightColor: highlightColor,
      elevation: 0.0,
      color: fillColor,
      shape: RoundedRectangleBorder(
          borderRadius: new BorderRadius.circular(30.0)),
      child: Text(
        text,
        style: TextStyle(
            fontWeight: FontWeight.bold, color: textColor, fontSize: 20),
      ),
      onPressed: onPressed,
    );
  }
}

