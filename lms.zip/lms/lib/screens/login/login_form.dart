import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../animation/fade_animation.dart';
import '../../blocs/login/login_bloc.dart';
import '../../common/inkwell_button.dart';
import '../../common/styles.dart';
import '../../utils/global_navigator_key.dart';

class LoginForm extends StatefulWidget {
  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  final FocusNode _usernameFocus = FocusNode();
  final FocusNode _passwordFocus = FocusNode();

  @override
  Widget build(BuildContext context) {
    //=====ON LOGIN BUTTON PRESSED ====
    _onLoginButtonPressed() {
      if (_formKey.currentState.validate()) {
        _formKey.currentState.save();

        BlocProvider.of<LoginBloc>(context).add(
          LoginButtonPressed(
            username: _usernameController.text,
            password: _passwordController.text,
          ),
        );
      }
    }

    //====== ON REGISTER WITH GOOGLE BUTTON PRESSED====
    _onAuthWithGoogleButtonPressed() {
      BlocProvider.of<LoginBloc>(context).add(
        AuthWithGoogleButtonPressed(),
      );
    }

    return BlocListener<LoginBloc, LoginState>(
      listener: (context, state) {
        if (state is LoginFailure) {
//          PlatformAlertDialog(
//            title: 'Sign in Failed',
//            content: state.error,
//            defaultActionText: 'OK',
//          ).show(context);
          Fluttertoast.showToast(
            msg: "${state.error}",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
          );
        }
        if (state is LoginSuccess) {
          //learn more above to schedulerBinding
          SchedulerBinding.instance.addPostFrameCallback((_) {
            GlobalNavigatorKey.navigatorKey.currentState.pop();
            GlobalNavigatorKey.navigatorKey.currentState.pushNamed('/');
          });
        }
        if (state is AuthFromGoogleSuccess) {
          SchedulerBinding.instance.addPostFrameCallback((_) {
            GlobalNavigatorKey.navigatorKey.currentState.pushNamed(
                '/register-with-google-detail',
                arguments: state.user);
          });
        }
        if (state is AuthFromGoogleFailure) {
          Fluttertoast.showToast(
            msg: "${state.error}",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
          );
        }
      },
      child: BlocBuilder<LoginBloc, LoginState>(
        builder: (context, state) {
          return Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FadeAnimation(
                    1,
                    Text(
                      "LOGIN",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 30,
                        color: CustomColors.whiteColor,
                      ),
                    )),
                SizedBox(
                  height: 50,
                ),
                TextFormField(
                  focusNode: _usernameFocus,
                  textInputAction: TextInputAction.next,
                  onFieldSubmitted: (term) {
                    _fieldFocusChange(context, _usernameFocus, _passwordFocus);
                  },
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Field cannot be empty!';
                    }
                    return null;
                  },
                  controller: _usernameController,
                  decoration: InputDecoration(
                    isDense: true,
                    prefixIcon: Icon(
                      Icons.mail,
                      color: CustomColors.whiteColor,
                    ),
                    labelText: "Enter Email",
                    labelStyle: Theme.of(context)
                        .textTheme
                        .headline5
                        .copyWith(color: CustomColors.whiteColor),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                TextFormField(
                  focusNode: _passwordFocus,
                  textInputAction: TextInputAction.done,
                  onFieldSubmitted: (value) {
                    _passwordFocus.unfocus();
                  },
                  controller: _passwordController,
                  obscureText: true,
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Field cannot be empty!';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    isDense: true,
                    prefixIcon: Icon(
                      Icons.lock,
                      color: CustomColors.whiteColor,
                    ),
                    labelText: "Enter Password",
                    labelStyle: Theme.of(context)
                        .textTheme
                        .headline5
                        .copyWith(color: CustomColors.whiteColor),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    FlatButton(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      onPressed: () {
                        Navigator.of(context).pushNamed('/password-reset');
                      },
                      child: Text(
                        "Forgot Password?",
                        style: Theme.of(context).textTheme.bodyText2.copyWith(
                              color: CustomColors.whiteColor,
                            ),
                      ),
                    ),
                  ],
                ),
                InkWellButton(
                  height: 40,
                  color: CustomColors.darkBlueColor,
                  text: state is! LoginLoading ? "Login" : "Please Wait",
                  onTap: state is! LoginLoading ? _onLoginButtonPressed : null,
                ),
                SizedBox(
                  height: 20,
                ),
                InkWellButton(
                  height: 40,
                  color: CustomColors.googleLoginButtonColor,
                  text: "Register With Gmail",
                  onTap: _onAuthWithGoogleButtonPressed,
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  _fieldFocusChange(
    BuildContext context,
    FocusNode currentFocus,
    FocusNode nextFocus,
  ) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }
}
