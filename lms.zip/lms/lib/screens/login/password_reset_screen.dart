import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:formz/formz.dart';

import '../../animation/fade_animation.dart';
import '../../blocs/password_reset/password_reset_bloc.dart';
import '../../common/inkwell_button.dart';
import '../../common/styles.dart';
import '../../repositories/password_reset_repository.dart';

class PasswordResetFormScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocProvider<PasswordResetBloc>(
        create: (context) => PasswordResetBloc(
          passwordResetRepository: PasswordResetRepository(),
        ),
        child: MyForm(),
      ),
    );
  }
}

class MyForm extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  _showToast(String serverResponse) {
    Fluttertoast.showToast(
      msg: "$serverResponse",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.red,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<PasswordResetBloc, PasswordResetFormState>(
      listener: (context, state) {
        if (state.status.isSubmissionSuccess) {
          _showToast(state.serverResponse);
        }
        if (state.status.isSubmissionFailure) {
          _showToast(state.serverResponse);
        }
      },
      child: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 30.0),
          height: MediaQuery.of(context).size.height,
          width: double.infinity,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("assets/images/login_bg.jpg"))),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FadeAnimation(
                    1,
                    Text(
                      "Reset password",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 30,
                        color: CustomColors.whiteColor,
                      ),
                    )),
                SizedBox(
                  height: 10,
                ),
                FadeAnimation(
                    1.1,
                    Text(
                      "Enter your email associated with your account and we will sent you a reset password link!",
                      style: Theme.of(context).textTheme.bodyText1.copyWith(
                            color: CustomColors.darkBlueColor,
                          ),
                    )),
                SizedBox(
                  height: 50,
                ),
                FadeAnimation(1.2, EmailInput()),
                SizedBox(
                  height: 50,
                ),
                FadeAnimation(1.3, SubmitButton()),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class EmailInput extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PasswordResetBloc, PasswordResetFormState>(
      buildWhen: (previous, current) => previous.email != current.email,
      builder: (context, state) {
        return TextFormField(
          initialValue: state.email.value,
          decoration: InputDecoration(
            isDense: true,
            prefixIcon: Icon(
              Icons.mail,
              color: CustomColors.whiteColor,
            ),
            labelText: "Enter Email",
            labelStyle: Theme.of(context)
                .textTheme
                .headline5
                .copyWith(color: CustomColors.whiteColor),
            errorText: state.email.invalid ? 'Invalid Email Address' : null,
          ),
          keyboardType: TextInputType.emailAddress,
          onChanged: (value) {
            context.bloc<PasswordResetBloc>().add(EmailChanged(email: value));
          },
        );
      },
    );
  }
}

class SubmitButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PasswordResetBloc, PasswordResetFormState>(
      buildWhen: (previous, current) => previous.status != current.status,
      builder: (context, state) {
        return InkWellButton(
          height: 40,
          color: state.status.isValidated
              ? CustomColors.darkBlueColor
              : Colors.grey,
          text: state.status.isSubmissionInProgress
              ? "Please Wait"
              : "Reset password",
          onTap: state.status.isValidated
              ? () => context
                  .bloc<PasswordResetBloc>()
                  .add(PasswordRestButtonClicked())
              : null,
        );
      },
    );
  }
}
