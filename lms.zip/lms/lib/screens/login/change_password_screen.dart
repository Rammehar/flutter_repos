import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../animation/fade_animation.dart';
import '../../blocs/register_with_google/register.dart';
import '../../common/inkwell_button.dart';
import '../../common/platform_alert_dialog.dart';
import '../../common/styles.dart';
import '../../models/user_model.dart';
import '../../utils/global_navigator_key.dart';

class ChangePasswordScreen extends StatelessWidget {
  final User user;
  ChangePasswordScreen(this.user) : assert(user != null);

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _pass = TextEditingController();
  final TextEditingController _confirmPass = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return BlocListener<RegisterBloc, RegisterWithGoogleState>(
      listener: (context, state) {
        if (state is RegisterSuccess) {
          SchedulerBinding.instance.addPostFrameCallback((_) {
            GlobalNavigatorKey.navigatorKey.currentState.pop();
            GlobalNavigatorKey.navigatorKey.currentState
                .pushNamed('/signin', arguments: state.message);
          });
        }
        if (state is RegisterFailure) {
          PlatformAlertDialog(
            title: 'Error Message',
            content: state.error,
            defaultActionText: 'OK',
          ).show(context);
//          _scaffoldKey.currentState.showSnackBar(
//            SnackBar(
//              content: Text('${state.error}'),
//              backgroundColor: Colors.red,
//            ),
//          );
        }
      },
      child: BlocBuilder<RegisterBloc, RegisterWithGoogleState>(
        builder: (context, state) {
          return Scaffold(
            key: _scaffoldKey,
            resizeToAvoidBottomInset: true,
            body: SingleChildScrollView(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 30.0),
                height: MediaQuery.of(context).size.height,
                width: double.infinity,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("assets/images/login_bg.jpg"))),
                child: Form(
                  key: _formKey,
                  autovalidate: true,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FadeAnimation(
                          1,
                          Text(
                            "ADD PASSWORD",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 25,
                              color: CustomColors.whiteColor,
                            ),
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      FadeAnimation(
                          1.1,
                          Text(
                            "Set a Password for this App",
                            style:
                                Theme.of(context).textTheme.bodyText1.copyWith(
                                      color: CustomColors.darkBlueColor,
                                    ),
                          )),
                      SizedBox(
                        height: 50,
                      ),
                      FadeAnimation(
                          1.1,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                child: TextFormField(
                                  obscureText: true,
                                  controller: _pass,
                                  onSaved: (value) {
                                    print(value);
                                  },
                                  validator: (value) {
                                    if (value.isEmpty) {
                                      return 'Please enter password';
                                    }
                                    return null;
                                  },
                                  decoration: InputDecoration(
                                    isDense: true,
                                    prefixIcon: Icon(
                                      Icons.lock,
                                      color: CustomColors.whiteColor,
                                    ),
                                    labelText: "Enter Password",
                                    labelStyle: Theme.of(context)
                                        .textTheme
                                        .headline5
                                        .copyWith(
                                            color: CustomColors.whiteColor),
                                  ),
                                ),
                              ),
                            ],
                          )),
                      SizedBox(
                        height: 20,
                      ),
                      FadeAnimation(
                          1.2,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                child: TextFormField(
                                  obscureText: true,
                                  controller: _confirmPass,
                                  onSaved: (value) {
                                    print(value);
                                  },
                                  validator: (value) {
                                    if (value.isEmpty) {
                                      return 'Please re-enter password';
                                    }
                                    if (value != _pass.text) {
                                      return "Password did not match";
                                    }
                                    return null;
                                  },
                                  decoration: InputDecoration(
                                    isDense: true,
                                    prefixIcon: Icon(
                                      Icons.lock,
                                      color: CustomColors.whiteColor,
                                    ),
                                    labelText: "Re-enter Password",
                                    labelStyle: Theme.of(context)
                                        .textTheme
                                        .headline5
                                        .copyWith(
                                            color: CustomColors.whiteColor),
                                  ),
                                ),
                              ),
                            ],
                          )),
                      SizedBox(
                        height: 40,
                      ),
                      FadeAnimation(
                        1.3,
                        InkWellButton(
                          height: 40,
                          color: CustomColors.darkBlueColor,
                          text: "Set Password",
                          onTap: () {
                            if (_formKey.currentState.validate()) {
                              _formKey.currentState.save();
                              //add password to User state
                              user.password = _pass.text;

                              BlocProvider.of<RegisterBloc>(context).add(
                                RegisterWithGoogleButtonPressed(user),
                              );
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  _onCreateUserButtonPressed(context) {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      //add password to User state
      user.password = _pass.text;

      BlocProvider.of<RegisterBloc>(context).add(
        RegisterWithGoogleButtonPressed(user),
      );
    }
  }
}
