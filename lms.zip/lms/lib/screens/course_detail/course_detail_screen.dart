import '../../common/inkwell_button.dart';
import '../../common/styles.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:share/share.dart';
import '../../blocs/authentication/authentication.dart';
import '../../blocs/cart/cart.dart';
import '../../blocs/course_sections/course_sections.dart';

import '../../common/common.dart';
import '../../models/course_model.dart';
import '../../models/section_model.dart';
import '../../widgets/expandable_text.dart';

import '../../widgets/my_cart_icon_button.dart';
import '../../utils/global_navigator_key.dart';

class CourseDetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CourseSectionsBloc, CourseSectionsState>(
      builder: (context, state) {
        if (state is CourseSectionsLoadSuccess) {
          return Scaffold(
            body: SafeArea(
              child: CustomScrollView(
                slivers: [
                  SliverAppBar(
                    actions: [
                      IconButton(
                        icon: Icon(
                          Icons.share,
                          color: Colors.white,
                        ),
                        onPressed: () {
                          final RenderBox box = context.findRenderObject();
                          Share.share(
                              "Best Course on Brain Mentors (${state.courseDetails.name}) https://www.brain-mentors.com",
                              subject: "Best Course of Brain Mentors",
                              sharePositionOrigin:
                                  box.localToGlobal(Offset.zero) & box.size);
                        },
                      ),
                      MyCartIconButton(),
                    ],
                    pinned: true,
                    expandedHeight: 250,
                    flexibleSpace: FlexibleSpaceBar(
                      background: Container(
                        color: CustomColors.dartGrayColor,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: 20,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 18.0),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Image.network(
                                        state.courseDetails.imageUrl,
                                        fit: BoxFit.fill,
                                        height: 100,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          state.courseDetails.name,
                                          style: Theme.of(context)
                                              .textTheme
                                              .headline4
                                              .copyWith(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                                color: Colors.white,
                                              ),
                                        ),
                                        SizedBox(
                                          height: 7,
                                        ),
                                        Text(
                                          "Author: ${state.courseDetails.author}",
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyText1
                                              .copyWith(
                                                color: Colors.white,
                                                fontSize: 12,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20.0,
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      'Price \u20B9 ${state.courseDetails.price}',
                                      style: Theme.of(context)
                                          .textTheme
                                          .headline6
                                          .copyWith(
                                            fontSize: 20,
                                            color: Colors.white,
                                          ),
                                    ),
                                  ),
                                  Expanded(
                                      child: _buildAddToCartButton(
                                          context, state.courseDetails)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  //course name and author name
                  SliverToBoxAdapter(
                    child: Container(
                      color: Theme.of(context).primaryColor,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 18.0,
                          vertical: 8,
                        ),
                        child: FittedBox(
                          child: Row(
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  color: Colors.yellow[900],
                                  borderRadius: BorderRadius.only(
                                      bottomRight: Radius.circular(10)),
                                ),
                                padding: EdgeInsets.symmetric(
                                  horizontal: 7,
                                  vertical: 3,
                                ),
                                child: Text(
                                  "BESTSELLER",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyText1
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ),
                              SizedBox(
                                width: 6,
                              ),
                              _buildKeyPointsChip(
                                  context,
                                  Icon(
                                    Icons.star,
                                    size: 14,
                                    color: Colors.white,
                                  ),
                                  "4.5",
                                  "Rating"),
                              SizedBox(
                                width: 6,
                              ),
                              _buildKeyPointsChip(
                                  context,
                                  Icon(
                                    Icons.account_circle,
                                    size: 14,
                                    color: Colors.white,
                                  ),
                                  "2450",
                                  "Students Enrolled!"),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  //price and button

                  SliverToBoxAdapter(
                    child: Card(
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        child: Padding(
                          padding: EdgeInsets.all(20),
                          child: Column(
                            children: [
                              Text(
                                "This Course Have!",
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Text("Full lifetime access"),
                              Text("Access on mobile, desktop, and TV"),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  //description
                  SliverToBoxAdapter(
                    child: Card(
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 18),
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          children: [
                            Text(
                              "Description",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    fontSize: 20,
                                  ),
                            ),
                            Divider(),
                            ExpandableText(
                                "${state.courseDetails.description}"),
                          ],
                        ),
                      ),
                    ),
                  ),

                  //outcome
                  SliverToBoxAdapter(
                    child: Card(
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 18),
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          children: [
                            Text(
                              "Outcome",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    fontSize: 20,
                                  ),
                            ),
                            Divider(),
                            ExpandableText("${state.courseDetails.outcome}"),
                          ],
                        ),
                      ),
                    ),
                  ),
                  //skills
                  SliverToBoxAdapter(
                    child: Card(
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 18),
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          children: [
                            Text(
                              "Skills Requirement",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    fontSize: 20,
                                  ),
                            ),
                            Divider(),
                            ExpandableText("${state.courseDetails.skills}"),
                          ],
                        ),
                      ),
                    ),
                  ),
                  //sections and content
                  SliverToBoxAdapter(
                    child: SectionList(sections: state.courseDetails.sections),
                  ),
                ],
              ),
            ),
          );
        }
        return LoadingIndicator();
      },
    );
  }

  Widget _buildKeyPointsChip(BuildContext context, Icon icon, text1, text2) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 7,
        vertical: 3,
      ),
      decoration: new BoxDecoration(
          border: Border.all(color: Colors.white, width: 0.5),
          borderRadius: new BorderRadius.circular(10)),
      child: Row(
        children: [
          icon,
          SizedBox(
            width: 4,
          ),
          RichText(
            text: TextSpan(children: [
              TextSpan(
                text: "$text1",
                style: Theme.of(context).textTheme.bodyText2.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 10),
              ),
              TextSpan(
                text: " $text2",
                style: Theme.of(context)
                    .textTheme
                    .bodyText2
                    .copyWith(color: Colors.white, fontSize: 10),
              ),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _buildAddToCartButton(BuildContext context, Course course) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, authState) {
        if (authState is Authenticated) {
          return BlocBuilder<CartBloc, CartState>(
            builder: (context, cartState) {
              if (cartState is CartLoadedSuccess) {
                var courses = cartState.cart.courses;
                var courseExists = courses.firstWhere(
                    (c) => c.courseId == course.courseId,
                    orElse: () => null);
                if (courseExists != null) {
                  return InkWellButton(
                    color: Theme.of(context).accentColor,
                    height: 40,
                    text: "View Cart",
                    onTap: () {
                      GlobalNavigatorKey.navigatorKey.currentState
                          .pushNamed('/cart-detail');
                    },
                  );
                }
              }
              return InkWellButton(
                color: Theme.of(context).accentColor,
                height: 40,
                text: cartState is! CartLoadingInProgress
                    ? "Add To Cart"
                    : "Please Wait",
                onTap: () {
                  if (cartState is CartLoadingInProgress) {
                    return;
                  }
                  BlocProvider.of<CartBloc>(context)
                      .add(AddToCart(course.courseId, authState.user));
                },
              );
            },
          );
        }
        //show add to cart button if user not logged in
        return InkWellButton(
          color: Theme.of(context).accentColor,
          height: 40,
          text: "Add To Cart",
          onTap: () {
            GlobalNavigatorKey.navigatorKey.currentState.pushNamed('/signin');
          },
        );
      },
    );
  }
}

class SectionList extends StatelessWidget {
  final List<Section> sections;
  SectionList({this.sections});

  @override
  Widget build(BuildContext context) {
    print("section build how many times");
    return ListView.builder(
      physics: BouncingScrollPhysics(),
      shrinkWrap: true,
      itemCount: sections.length,
      itemBuilder: (context, index) {
        return Card(
          child: ExpansionTile(
            title: Text(
              "${sections[index].sectionName}",
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            children: [
              SectionContents(sections[index].contents),
            ],
          ),
        );
      },
    );
  }
}

class SectionContents extends StatelessWidget {
  final List contents;
  SectionContents(this.contents);
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, state) {
        if (state is Authenticated) {
          return _buildSectionContents(contents, state.user);
        }
        return _buildSectionContents(contents);
      },
    );
  }

  _buildSectionContents(contents, [user]) {
    return ListView.builder(
      physics: BouncingScrollPhysics(),
      shrinkWrap: true,
      itemCount: contents.length,
      itemBuilder: (context, index) {
        var isPaid = contents[index].isPaid;
        var videoUrl = user == null
            ? null
            : "${contents[index].mpdUrl}?tokenid=${user.tokenId}";
        return Container(
          //padding: EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          child: (isPaid != "F")
              ? ListTile(
                  dense: true,
                  title: Row(
                    children: [
                      Text(
                        "${contents[index].serialNo}",
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "${contents[index].videoName}",
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              "Video - ${contents[index].duration} mins",
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.grey[600],
                                fontWeight: FontWeight.w500,
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              : ListTile(
                  dense: true,
                  title: Row(
                    children: [
                      Text(
                        "${contents[index].serialNo}",
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "${contents[index].videoName}",
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              "Video - ${contents[index].duration} mins",
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.grey[600],
                                fontWeight: FontWeight.w500,
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                  trailing: videoUrl == null
                      ? FlatButton(
                          child: Text(
                            "Preview",
                            style: TextStyle(color: Colors.blue, fontSize: 12),
                          ),
                          onPressed: () {
                            GlobalNavigatorKey.navigatorKey.currentState
                                .pushNamed("/signin");
                          },
                        )
                      : FlatButton(
                          child: Text(
                            "Preview",
                            style: TextStyle(color: Colors.blue, fontSize: 12),
                          ),
                          onPressed: () {
                            GlobalNavigatorKey.navigatorKey.currentState
                                .pushNamed("/preview-video",
                                    arguments: videoUrl);
                          },
                        ),
                ),
        );
      },
    );
  }
}
