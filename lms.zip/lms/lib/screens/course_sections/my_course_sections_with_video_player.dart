import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/course_sections/course_sections.dart';
import '../../common/common.dart';
import '../../common/loading_indicator.dart';
import '../../models/user_model.dart';
import '../../screens/flick_video_player/custom_orientation_player.dart';

class CourseSectionsContents extends StatelessWidget {
  final User user;
  CourseSectionsContents(this.user);

  @override
  Widget build(BuildContext context) {
    print("Course inside Build?");
    return Scaffold(
      body: BlocBuilder<CourseSectionsBloc, CourseSectionsState>(
        builder: (context, state) {
          if (state is CourseSectionsLoadSuccess) {
            return Container(
              child: CustomOrientationPlayer(
                course: state.courseDetails,
                user: user,
              ),
            );
          }
          return LoadingIndicator();
        },
      ),
    );
  }
}
